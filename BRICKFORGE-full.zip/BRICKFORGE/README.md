# BRICKFORGE - BUILD ANYTHING. WITH ANY AI.

Connect your browser AI (Claude, ChatGPT, Gemini) to Roblox Studio.

```
AI chat in your browser -> BRICKFORGE extension -> bridge on your PC (start.bat) -> Roblox Studio MCP
```

## Setup (about 3 minutes)
1. **Extract the whole zip** (right-click > Extract All). Don't run start.bat from inside the zip.
2. **Install Python 3.9+** from python.org if you don't have it - tick "Add python.exe to PATH". BRICKFORGE needs no other downloads.
3. **Roblox Studio:** open a place, then Assistant > ... > Manage MCP Servers > **Enable Studio as MCP Server** (first time only).
4. **Double-click `start.bat`** and keep the window open (minimize it).
5. **Install the extension:** open `chrome://extensions` (or `edge://extensions`), turn on **Developer mode**, click **Load unpacked**, select the `extension` folder.
6. Open **claude.ai**, **chatgpt.com** or **gemini.google.com**, start a new chat, click **Start session** (bottom-right bar), then ask for what you want to build.

Bar dot: **green** = bridge + a place is open - **yellow** = bridge OK but Studio isn't ready (hover for the reason) - **grey** = bridge offline, run start.bat.

## Honest status
| Part | Status |
|---|---|
| Bridge (WebSocket <-> Studio MCP, tool discovery, error handling, recovery, watchdog) | Tested against a mock MCP server (25 tests). Not yet tested against real Studio. |
| Extension <-> bridge connection (real background.js, real bridge) | Tested end-to-end (14 tests), incl. bridge restart + auto-reconnect. |
| Roblox asset upload (Open Cloud): key storage, request shape, errors | Tested against a **mock** Roblox API (21 tests); OAuth sign-in flow incl. PKCE, refresh, revoke (17 tests). Not yet tried against real Roblox. |
| Extension protocol parser | Unit-tested (15 tests). |
| Claude / ChatGPT / Gemini adapters | **Experimental - never tested on the live sites.** Chat sites change often; if the bar can't find the chat box, please report it. |
| Other providers, API providers, project memory, desktop UI, rollback, confirmations | Not built yet. |

## Connecting your Roblox account (the "Select Account to Continue" page)
Click **Connect BRICKFORGE to Roblox** (website, or extension > *Roblox link & uploads*). Your browser opens
`http://127.0.0.1:17640/connect` (the local bridge - so `start.bat` must be running), which sends you to **Roblox's own
sign-in/consent page**. Press Continue and you're connected. BRICKFORGE never sees your password.

**One-time setup by whoever runs BRICKFORGE:** register an OAuth 2.0 app at create.roblox.com/dashboard/credentials
(redirect URL `http://127.0.0.1:17640/oauth/callback`, permissions openid, profile, asset:read, asset:write, public/PKCE client),
then paste its Client ID in the extension (Set up the Roblox app) - or put it in `bridge/oauth_app.json` before sharing the zip.
Roblox may require review before other people can authorize an OAuth app; if Roblox rejects the redirect URL or blocks other
users, use the API-key option under *Advanced*.

## Linking with an API key instead (advanced)
Extension icon > **Roblox link & uploads**. You create a limited **Open Cloud API key** at create.roblox.com/dashboard/credentials
(permission: **assets**, Read + Write; owner = you or your group), then paste it + your user/group ID there.
Supported: Decal/Image, Audio, Model, Animation (20 MB max each, per Roblox's rules). The result is a ready-to-use `rbxassetid://...`.
- BRICKFORGE never asks for your Roblox password or cookies. Do not type your key on any website.
- The key is stored on your PC only: encrypted with Windows DPAPI on Windows; an owner-only (not encrypted) file elsewhere.
- AI chats cannot trigger uploads - only that options page can.

## Security
The bridge listens on 127.0.0.1 only and rejects connections from web pages (only the extension can connect). BRICKFORGE never reads your passwords or cookies.

## License / credits
GPL-3.0 (see LICENSE). The bridge architecture and the Studio launcher logic follow the design of the GPL-3.0 project **ZeroScript** by sebattfg; BRICKFORGE is an independent re-implementation and does not use ZeroScript's name, logo or assets.

## "Refused to connect" when I click Connect
Chrome shows that when **nothing is listening on 127.0.0.1:17640** - i.e. `start.bat` isn't running or it closed/crashed.
Run `start.bat` from the *extracted* folder and keep the window open; the BRICKFORGE page then opens by itself (or open
http://127.0.0.1:17640). If it still fails, the start.bat window shows the reason (usually: Python missing).

## Running the tests (optional)
`cd bridge && python tests/test_bridge.py` - `python tests/test_cloud.py` - `python tests/test_oauth.py` - `node tests/protocol.test.js` - `node tests/integration.test.js` (Node 22+)
