import asyncio, os, sys
from . import log as logmod
from .manager import MCPManager, ROOT
from .server import Bridge, run


def main():
    logmod.setup(os.path.join(ROOT, "logs"))
    mgr = MCPManager()
    try:
        mgr.load_config()
    except Exception as e:
        print(f"[brickforge] {e}"); return 1
    bridge = Bridge(mgr)

    async def go():
        try:
            await run(mgr, bridge)
        finally:
            await mgr.shutdown()
    try:
        asyncio.run(go())
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
