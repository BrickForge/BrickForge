"""Roblox Open Cloud link: store an API key locally, upload assets via the official Assets API.

Security model
- The key is created by the user in Creator Hub (Open Cloud > API Keys) with ONLY the Assets permission.
- BRICKFORGE never sees a Roblox password or .ROBLOSECURITY cookie, and never asks for them.
- The key is stored outside the program folder: Windows = encrypted with DPAPI (tied to your Windows user);
  other systems = a file readable only by you (chmod 600; NOT encrypted - status says so).
- The key is never logged, never returned by any message (only 'ends in XXXX'), never sent to any AI.
- Uploads are never triggered by an AI tool call - only by an explicit request from the options page."""
from __future__ import annotations
import asyncio, base64, hashlib, json, os, re, secrets, stat, sys, time, urllib.error, urllib.parse, urllib.request, uuid

from .log import log
from .mcp_client import BridgeError

BASE = os.environ.get("BRICKFORGE_CLOUD_URL", "https://apis.roblox.com").rstrip("/")
MAX_BYTES = 20 * 1024 * 1024
# Types from Roblox's Assets API guide (video excluded: files up to 3.75 GB can't pass through the extension).
TYPES = {
    "Decal": {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".bmp": "image/bmp", ".tga": "image/tga"},
    "Audio": {".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".wav": "audio/wav", ".flac": "audio/flac"},
    "Model": {".fbx": "model/fbx", ".gltf": "model/gltf+json", ".glb": "model/gltf-binary", ".rbxm": "model/x-rbxm", ".rbxmx": "model/x-rbxm"},
    "Animation": {".rbxm": "model/x-rbxm", ".rbxmx": "model/x-rbxm"},
}


def _home() -> str:
    d = os.environ.get("BRICKFORGE_HOME") or (os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "BRICKFORGE")
                                              if sys.platform == "win32" else os.path.expanduser("~/.brickforge"))
    os.makedirs(d, exist_ok=True)
    return d


# ---- secret storage -------------------------------------------------------------------------
def _dpapi(data: bytes, protect: bool) -> bytes:
    import ctypes
    from ctypes import wintypes as w

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", w.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    buf = ctypes.create_string_buffer(data, len(data))
    inb, out = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(inb), None, None, None, None, 0, ctypes.byref(out)):
        raise BridgeError("secret_store", "Windows could not encrypt/decrypt the stored key.")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


def _path() -> str:
    return os.path.join(_home(), "roblox_link.bin")


def _save(secret: dict):
    raw = json.dumps(secret).encode()
    enc = _dpapi(raw, True) if sys.platform == "win32" else raw
    p = _path()
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(enc)
    if sys.platform != "win32":
        os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)


def _load():
    try:
        with open(_path(), "rb") as f:
            raw = f.read()
        return json.loads((_dpapi(raw, False) if sys.platform == "win32" else raw).decode())
    except FileNotFoundError:
        return None
    except BridgeError:
        raise
    except Exception:
        raise BridgeError("secret_store", "The saved Roblox link is unreadable. Unlink and link again.")


# ---- OAuth 2.0 (PKCE) "Connect to Roblox" ---------------------------------------------------
def _store_label():
    return "encrypted (Windows DPAPI)" if sys.platform == "win32" else "owner-only file (not encrypted)"


def client_id() -> str:
    """Public OAuth client id of the BRICKFORGE app registered in Creator Hub (not a secret)."""
    v = os.environ.get("BRICKFORGE_OAUTH_CLIENT_ID", "").strip()
    if v:
        return v
    for path in (os.path.join(_home(), "oauth_app.json"), os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "oauth_app.json")):
        try:
            with open(path) as f:
                v = str(json.load(f).get("client_id", "")).strip()
            if v: return v
        except Exception:
            pass
    return ""


def set_client_id(cid: str) -> dict:
    cid = (cid or "").strip()
    if not re.fullmatch(r"\d{6,30}", cid):
        raise BridgeError("bad_input", "A Roblox OAuth client ID is a long number (Creator Hub > Credentials > your OAuth app).")
    with open(os.path.join(_home(), "oauth_app.json"), "w") as f:
        json.dump({"client_id": cid}, f)
    return status()


SCOPES = "openid profile asset:read asset:write"
_pending: dict = {}   # state -> (code_verifier, created_at); single use, 10 minute life


def oauth_begin(redirect_uri: str) -> str:
    cid = client_id()
    if not cid:
        raise BridgeError("no_client_id", "The BRICKFORGE Roblox app isn't set up yet (no Client ID).")
    now = time.time()
    for k in [k for k, v in _pending.items() if now - v[1] > 600]:
        _pending.pop(k, None)
    verifier, state = secrets.token_urlsafe(48), secrets.token_urlsafe(24)
    _pending[state] = (verifier, now)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    q = urllib.parse.urlencode({"client_id": cid, "redirect_uri": redirect_uri, "scope": SCOPES, "response_type": "code",
                                "code_challenge": challenge, "code_challenge_method": "S256", "state": state}, quote_via=urllib.parse.quote)
    return f"{BASE}/oauth/v1/authorize?{q}"


def _token(form: dict) -> dict:
    return _http("POST", f"{BASE}/oauth/v1/token", {}, urllib.parse.urlencode(form).encode(), "application/x-www-form-urlencoded")


def oauth_finish(code: str, state: str, redirect_uri: str) -> dict:
    ent = _pending.pop(state or "", None)
    if not ent or time.time() - ent[1] > 600:
        raise BridgeError("bad_state", "This sign-in link expired or was already used. Start again from BRICKFORGE.")
    if not code:
        raise BridgeError("bad_input", "Roblox did not return a sign-in code.")
    tok = _token({"grant_type": "authorization_code", "code": code, "code_verifier": ent[0], "client_id": client_id(), "redirect_uri": redirect_uri})
    me = _http("GET", f"{BASE}/oauth/v1/userinfo", {"Authorization": "Bearer " + tok["access_token"]})
    _save({"mode": "oauth", "access_token": tok["access_token"], "refresh_token": tok.get("refresh_token"),
           "expires_at": time.time() + int(tok.get("expires_in", 900)), "user_id": str(me.get("sub")),
           "username": me.get("preferred_username") or me.get("name"), "linked_at": int(time.time())})
    log.info("Roblox account connected via OAuth (user %s)", me.get("sub"))   # tokens are never logged
    return status()


def _bearer(sec: dict) -> dict:
    if time.time() > sec["expires_at"] - 60:   # refresh transparently
        try:
            tok = _token({"grant_type": "refresh_token", "refresh_token": sec["refresh_token"], "client_id": client_id()})
        except BridgeError as e:
            if e.kind in ("http_400", "http_401"):
                raise BridgeError("reconnect", "Your Roblox connection expired. Click Connect to Roblox again.")
            raise
        sec.update(access_token=tok["access_token"], refresh_token=tok.get("refresh_token") or sec["refresh_token"],
                   expires_at=time.time() + int(tok.get("expires_in", 900)))
        _save(sec)
    return {"Authorization": "Bearer " + sec["access_token"]}


# ---- public API -----------------------------------------------------------------------------
def status() -> dict:
    s = _load()
    if s and s.get("mode") == "oauth":
        return {"linked": True, "mode": "oauth", "owner_type": "user", "owner_id": s["user_id"], "username": s.get("username"),
                "key_hint": "connected with Roblox login", "storage": _store_label(), "linked_at": s.get("linked_at")}
    if not s:
        return {"linked": False, "client_id_set": bool(client_id()), "storage": "encrypted (Windows DPAPI)" if sys.platform == "win32" else "owner-only file (not encrypted)"}
    return {"linked": True, "mode": "key", "owner_type": s["owner_type"], "owner_id": s["owner_id"], "key_hint": "ends in " + s["key"][-4:],
            "storage": "encrypted (Windows DPAPI)" if sys.platform == "win32" else "owner-only file (not encrypted)",
            "linked_at": s.get("linked_at")}


def link(key: str, owner_type: str, owner_id: str) -> dict:
    key, owner_id = (key or "").strip(), str(owner_id or "").strip()
    if owner_type not in ("user", "group"):
        raise BridgeError("bad_input", "Owner must be 'user' or 'group'.")
    if not re.fullmatch(r"\d{1,20}", owner_id):
        raise BridgeError("bad_input", "Your user/group ID must be numbers only (see the number in your Roblox profile or group URL).")
    if len(key) < 20 or re.search(r"\s", key):
        raise BridgeError("bad_input", "That doesn't look like an Open Cloud API key (it should be one long string with no spaces).")
    if len(key) > 4000:
        raise BridgeError("bad_input", "Key is too long.")
    _save({"key": key, "owner_type": owner_type, "owner_id": owner_id, "linked_at": int(time.time())})
    log.info("Roblox link saved (owner %s %s)", owner_type, owner_id)  # never the key
    return status()


def unlink() -> dict:
    try:
        sec = _load()
        if sec and sec.get("mode") == "oauth" and sec.get("refresh_token"):
            _http("POST", f"{BASE}/oauth/v1/token/revoke", {}, urllib.parse.urlencode({"token": sec["refresh_token"], "client_id": client_id()}).encode(), "application/x-www-form-urlencoded")
    except Exception:
        pass   # best effort; local deletion below is what matters
    try:
        os.remove(_path())
    except FileNotFoundError:
        pass
    log.info("Roblox link removed")
    return status()


def _multipart(fields: dict, fname: str, ctype: str, content: bytes):
    b = "----bf" + uuid.uuid4().hex
    parts = [f'--{b}\r\nContent-Disposition: form-data; name="request"\r\nContent-Type: application/json\r\n\r\n{json.dumps(fields)}\r\n'.encode(),
             f'--{b}\r\nContent-Disposition: form-data; name="fileContent"; filename="{fname}"\r\nContent-Type: {ctype}\r\n\r\n'.encode(), content,
             f"\r\n--{b}--\r\n".encode()]
    return b"".join(parts), f"multipart/form-data; boundary={b}"


def _http(method: str, url: str, auth, body: bytes = None, ctype: str = None):
    h = {"x-api-key": auth} if isinstance(auth, str) else dict(auth or {})
    if ctype: h["Content-Type"] = ctype
    req = urllib.request.Request(url, data=body, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = (json.loads(e.read()).get("message") or "")[:200]
        except Exception:
            pass
        hints = {401: "Roblox rejected the key. Check it was copied fully and hasn't expired or been disabled.",
                 403: "The key lacks permission. Give it the Assets permission with Read+Write, and make sure its owner matches the user/group ID you linked.",
                 429: "Roblox rate limit reached. Wait a bit and try again (audio/video have monthly or daily upload caps).",
                 400: "Roblox rejected the request: " + detail}
        raise BridgeError(f"http_{e.code}", hints.get(e.code, f"Roblox returned HTTP {e.code}. {detail}"))
    except urllib.error.URLError as e:
        raise BridgeError("network", f"Could not reach Roblox ({e.reason}). Check your internet connection.")


async def upload(data_b64: str, filename: str, asset_type: str, display_name: str, description: str = "", poll_seconds: float = 60) -> dict:
    s = _load()
    if not s:
        raise BridgeError("not_linked", "No Roblox account is linked yet. Link it first on the options page.")
    oauth = s.get("mode") == "oauth"
    owner_type, owner_id = ("user", s["user_id"]) if oauth else (s["owner_type"], s["owner_id"])
    auth_for = (lambda: _bearer(s)) if oauth else (lambda: s["key"])
    ext = os.path.splitext(filename or "")[1].lower()
    allowed = TYPES.get(asset_type)
    if not allowed:
        raise BridgeError("bad_type", f"Unsupported asset type '{asset_type}'. Supported: {', '.join(TYPES)}.")
    if ext not in allowed:
        raise BridgeError("bad_type", f"{asset_type} accepts {', '.join(allowed)} - not '{ext or 'no extension'}'.")
    name = (display_name or "").strip()[:50]
    if not name:
        raise BridgeError("bad_input", "Give the asset a name.")
    try:
        content = base64.b64decode(data_b64, validate=True)
    except Exception:
        raise BridgeError("bad_input", "File data was not valid.")
    if not content or len(content) > MAX_BYTES:
        raise BridgeError("too_large", "Files must be between 1 byte and 20 MB.")
    fields = {"assetType": asset_type, "displayName": name, "description": (description or "")[:1000],
              "creationContext": {"creator": {("userId" if owner_type == "user" else "groupId"): owner_id}}}
    body, ctype = _multipart(fields, os.path.basename(filename), allowed[ext], content)
    log.info("cloud upload: %s '%s' (%d bytes)", asset_type, name, len(content))
    op = await asyncio.to_thread(lambda: _http("POST", f"{BASE}/assets/v1/assets", auth_for(), body, ctype))
    opid = (op.get("path") or "").split("/")[-1]
    if not opid:
        raise BridgeError("bad_response", "Roblox accepted the upload but returned no operation id.")
    deadline, delay = time.monotonic() + poll_seconds, 0.5
    while time.monotonic() < deadline:
        r = op if op.get("done") else await asyncio.to_thread(lambda: _http("GET", f"{BASE}/assets/v1/operations/{opid}", auth_for()))
        op = r
        if r.get("done"):
            if r.get("error") or not r.get("response"):
                raise BridgeError("upload_failed", "Roblox could not process the asset: " + str((r.get("error") or {}).get("message", "unknown reason"))[:300])
            a = r["response"]
            ms = (a.get("moderationResult") or {}).get("moderationState", "")
            return {"ok": True, "assetId": a.get("assetId"), "rbxassetid": f"rbxassetid://{a.get('assetId')}", "displayName": a.get("displayName"),
                    "assetType": asset_type, "moderation": ms.replace("MODERATION_STATE_", "").title() or "Unknown"}
        await asyncio.sleep(delay); delay = min(delay * 1.6, 5)
    raise BridgeError("pending", f"Roblox is still processing it (operation {opid}). Check Creator Dashboard > Creations in a minute.")
