import logging, os, sys
from logging.handlers import RotatingFileHandler

log = logging.getLogger("brickforge")


def setup(log_dir: str):
    os.makedirs(log_dir, exist_ok=True)
    log.setLevel(logging.DEBUG)
    fh = RotatingFileHandler(os.path.join(log_dir, "bridge.log"), maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    sh = logging.StreamHandler(sys.stdout); sh.setLevel(logging.INFO)
    sh.setFormatter(logging.Formatter("[brickforge] %(message)s"))
    log.handlers = [fh, sh]
