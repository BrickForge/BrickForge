"""Aggregates every configured MCP server and routes tool calls by name."""
from __future__ import annotations
import asyncio, json, os
from typing import Dict, Optional, Tuple

from .log import log
from .mcp_client import MCPClient, BridgeError

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.environ.get("BRICKFORGE_CONFIG", os.path.join(ROOT, "config.json"))


def read_config() -> dict:
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {"mcpServers": {}}
    except Exception as e:
        raise BridgeError("bad_config", f"config.json is not valid JSON: {e}")


class MCPManager:
    def __init__(self):
        self.clients: Dict[str, MCPClient] = {}
        self.index: Dict[str, Tuple[MCPClient, str]] = {}

    def load_config(self):
        for sid, spec in (read_config().get("mcpServers") or {}).items():
            cmd = spec.get("command", "")
            if cmd.lower().endswith(".py") and not os.path.isabs(cmd):
                cmd = os.path.join(ROOT, cmd)
            self.clients[sid] = MCPClient(sid, cmd, spec.get("args"), spec.get("env"), cwd=ROOT)
        log.info("configured %d MCP server(s): %s", len(self.clients), ", ".join(self.clients) or "(none)")

    async def start_all(self):
        # In parallel: a slow/absent Studio must not delay unrelated servers.
        async def one(c):
            try:
                await c.start()
            except Exception as e:
                log.error("[%s] failed to start: %s", c.id, e)
        await asyncio.gather(*(one(c) for c in self.clients.values()))
        self.rebuild()

    def rebuild(self):
        idx = {}
        for sid, c in self.clients.items():
            for t in c.tools:
                n = t.get("name")
                if n:
                    idx[n if n not in idx else f"{sid}/{n}"] = (c, n)
        self.index = idx

    def tools(self):
        out = []
        for adv, (c, real) in self.index.items():
            t = next((x for x in c.tools if x.get("name") == real), None)
            if t:
                out.append({**t, "name": adv, "server": c.id})
        return out

    async def refresh(self):
        for c in self.clients.values():
            try:
                if not c.alive():
                    await c.start(tool_wait=3)
                else:
                    await c.refresh_tools()
            except Exception as e:
                log.warning("[%s] refresh failed: %s", c.id, e)
        self.rebuild()
        return self.tools()

    async def call(self, name: str, args: dict, timeout: float) -> dict:
        ent = self.index.get(name)
        if ent is None:
            self.rebuild(); ent = self.index.get(name)
        if ent is None:
            raise BridgeError("unknown_tool", f"unknown tool '{name}'")
        c, real = ent
        return await c.call_tool(real, args, timeout)

    async def restart(self, sid: Optional[str] = None):
        for c in ([self.clients[sid]] if sid in self.clients else self.clients.values()):
            try: await c.restart()
            except Exception as e: log.error("[%s] restart failed: %s", c.id, e)
        self.rebuild()

    async def watch(self, interval: float = 5.0):
        """Watchdog: revive dead servers and re-poll empty tool lists, so opening Studio AFTER
        the bridge started just works (StudioMCP advertises 0 tools until Studio attaches).
        Exponential backoff per server so a missing Studio doesn't spam the log."""
        fails = {}; wait = {}
        while True:
            await asyncio.sleep(interval)
            changed = False
            for c in list(self.clients.values()):
                if c._start_lock.locked():
                    continue
                if wait.get(c.id, 0) > 0:
                    wait[c.id] -= 1; continue
                try:
                    before = len(c.tools)
                    if not c.alive():
                        await c.start(tool_wait=2)
                    elif not c.tools:
                        await c.refresh_tools(3)
                    ok = c.alive() and bool(c.tools)
                    changed |= len(c.tools) != before
                except Exception:
                    ok = False
                fails[c.id] = 0 if ok else min(fails.get(c.id, 0) + 1, 5)
                wait[c.id] = 0 if ok else 2 ** fails[c.id] - 1   # skip this many ticks (max ~31)
            self.rebuild()  # cheap; keeps the index in step with servers coming and going

    def health(self):
        return [{"id": s, "alive": c.alive(), "tools": len(c.tools), "error": c.start_error,
                 "last_exit": c.last_exit, "stderr_tail": list(c.stderr_tail)} for s, c in self.clients.items()]

    async def shutdown(self):
        await asyncio.gather(*(c.stop() for c in self.clients.values()), return_exceptions=True)
