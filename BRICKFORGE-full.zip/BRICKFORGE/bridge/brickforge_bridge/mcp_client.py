"""Async MCP stdio client. One reader task per process; replies matched by
JSON-RPC id to per-request Futures, so concurrent calls can never receive each
other's results. Every call ends in a result or a structured BridgeError."""
from __future__ import annotations
import asyncio, json, os, sys, time
from collections import deque
from typing import Any, Dict, List, Optional

from .log import log


class BridgeError(Exception):
    def __init__(self, kind: str, message: str):
        super().__init__(message)
        self.kind, self.message = kind, message

    def to_dict(self):
        return {"ok": False, "kind": self.kind, "error": self.message}


# Studio's proxy briefly loses its Studio binding on some machines (seen in the
# ZeroScript changelog); one short retry rides through it.
TRANSIENT = ("no studio", "not connected", "disconnected for proxy", "unable to find an active studio")


class MCPClient:
    def __init__(self, server_id: str, command: str, args=None, env=None, cwd=None):
        self.id, self.command, self.args = server_id, command, list(args or [])
        self.env, self.cwd = env or {}, cwd
        self.proc: Optional[asyncio.subprocess.Process] = None
        self.tools: List[dict] = []
        self.pending: Dict[int, asyncio.Future] = {}
        self._next = 1
        self._write_lock = asyncio.Lock()
        self._start_lock = asyncio.Lock()
        self._call_lock = asyncio.Lock()  # single stdio pipe: one tool call at a time
        self.stderr_tail: deque = deque(maxlen=8)
        self.last_exit: Optional[int] = None
        self.start_error: Optional[str] = None
        self.restarts: List[float] = []
        self._tasks: List[asyncio.Task] = []

    def alive(self) -> bool:
        return self.proc is not None and self.proc.returncode is None

    def _argv(self) -> List[str]:
        cmd = [os.path.expandvars(os.path.expanduser(self.command))] + \
              [os.path.expandvars(a) for a in self.args]
        if cmd[0].lower().endswith(".py"):
            cmd = [sys.executable] + cmd
        elif sys.platform == "win32" and os.path.basename(cmd[0]).lower() in ("npx", "npm", "yarn", "pnpm", "bunx"):
            cmd = ["cmd.exe", "/c"] + cmd  # .cmd shims can't be exec'd directly
        return cmd

    async def start(self, tool_wait: float = 12.0):
        async with self._start_lock:
            if self.alive():
                return
            argv = self._argv()
            env = dict(os.environ); env.update({k: os.path.expandvars(v) for k, v in self.env.items()})
            log.info("[%s] launching %s", self.id, " ".join(argv))
            try:
                self.proc = await asyncio.create_subprocess_exec(
                    *argv, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE, cwd=self.cwd, env=env, limit=2 ** 26)
            except FileNotFoundError:
                self.start_error = f"command not found: '{argv[0]}' (server '{self.id}')"
                raise BridgeError("start_failed", self.start_error)
            except OSError as e:
                self.start_error = f"could not launch '{argv[0]}': {e}"
                raise BridgeError("start_failed", self.start_error)
            self.start_error = None
            self.pending.clear()
            self._tasks = [asyncio.create_task(self._reader(self.proc)),
                           asyncio.create_task(self._stderr(self.proc))]
            await self._request("initialize", {"protocolVersion": "2024-11-05", "capabilities": {},
                                               "clientInfo": {"name": "brickforge-bridge", "version": "0.1"}}, 30)
            await self._notify("notifications/initialized")
            # StudioMCP advertises 0 tools until Studio attaches; keep polling briefly.
            deadline = time.monotonic() + tool_wait
            while time.monotonic() < deadline:
                if await self.refresh_tools(3) or not self.alive():
                    break
                await asyncio.sleep(1.0)
            log.info("[%s] up, %d tools", self.id, len(self.tools))

    async def stop(self):
        for f in list(self.pending.values()):
            if not f.done():
                f.set_exception(BridgeError("server_stopped", f"server '{self.id}' stopped"))
        self.pending.clear()
        p, self.proc = self.proc, None
        self.tools = []  # a stopped server advertises nothing
        if p and p.returncode is None:
            try:
                if sys.platform == "win32":  # kill the whole tree (launcher -> StudioMCP.exe)
                    k = await asyncio.create_subprocess_exec("taskkill", "/F", "/T", "/PID", str(p.pid),
                                                             stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
                    await asyncio.wait_for(k.wait(), 8)
                else:
                    p.terminate()
                await asyncio.wait_for(p.wait(), 5)
            except Exception:
                try: p.kill()
                except Exception: pass
        for t in self._tasks:
            t.cancel()

    async def restart(self):
        log.warning("[%s] restarting", self.id)
        self.restarts = [t for t in self.restarts if time.time() - t < 300] + [time.time()]
        await self.stop(); await asyncio.sleep(0.3); await self.start()

    async def _reader(self, proc):
        try:
            while True:
                line = await proc.stdout.readline()
                if not line:
                    break
                try:
                    msg = json.loads(line)
                except Exception:
                    continue  # stray non-JSON on stdout
                fut = self.pending.get(msg.get("id")) if isinstance(msg, dict) else None
                if fut and not fut.done():
                    fut.set_result(msg)
        except Exception as e:
            log.warning("[%s] reader error: %s", self.id, e)
        self.last_exit = proc.returncode if proc.returncode is not None else await proc.wait()
        log.warning("[%s] process ended (exit %s)", self.id, self.last_exit)
        for f in list(self.pending.values()):
            if not f.done():
                f.set_exception(BridgeError("server_died", f"server '{self.id}' exited ({self.last_exit})"))

    async def _stderr(self, proc):
        try:
            while True:
                line = await proc.stderr.readline()
                if not line:
                    break
                s = line.decode("utf-8", "replace").rstrip()
                if s:
                    self.stderr_tail.append(s)
        except Exception:
            pass

    async def _send(self, payload: dict):
        if not self.alive():
            raise BridgeError("server_down", f"server '{self.id}' is not running")
        async with self._write_lock:
            self.proc.stdin.write((json.dumps(payload) + "\n").encode())
            await self.proc.stdin.drain()

    async def _notify(self, method, params=None):
        await self._send({"jsonrpc": "2.0", "method": method, "params": params or {}})

    async def _request(self, method, params, timeout) -> dict:
        rid = self._next; self._next += 1
        fut = asyncio.get_running_loop().create_future()
        self.pending[rid] = fut
        try:
            await self._send({"jsonrpc": "2.0", "id": rid, "method": method, "params": params or {}})
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            raise BridgeError("timeout", f"no response from '{self.id}' to {method} after {timeout:g}s")
        finally:
            self.pending.pop(rid, None)

    async def refresh_tools(self, timeout=20) -> List[dict]:
        try:
            msg = await self._request("tools/list", {}, timeout)
            if "result" in msg:
                self.tools = msg["result"].get("tools", [])
        except BridgeError:
            pass
        return self.tools

    async def call_tool(self, name: str, arguments: dict, timeout: float) -> dict:
        async with self._call_lock:
            for attempt in (1, 2):
                if not self.alive():
                    await self.restart()
                try:
                    msg = await self._request("tools/call", {"name": name, "arguments": arguments}, timeout)
                except BridgeError as e:
                    if e.kind == "server_died":
                        # The call may or may not have executed before the crash. Re-sending
                        # could duplicate side effects (e.g. create a Part twice), so recover
                        # the server for the NEXT call but report an unknown outcome now.
                        try: await self.restart()
                        except Exception: pass
                        raise BridgeError("server_died", f"{e.message}. The call may or may not have run - "
                                                         "inspect Studio state before retrying.")
                    raise
                if msg.get("error"):
                    txt = msg["error"].get("message", json.dumps(msg["error"]))
                    if attempt == 1 and any(t in txt.lower() for t in TRANSIENT):
                        await asyncio.sleep(1.5); continue
                    raise BridgeError("tool_error", txt)
                res = msg.get("result", {})
                content = res.get("content", [])
                text = "\n".join(c.get("text", "") for c in content if c.get("type") == "text")
                images = [{"data": c["data"], "mimeType": c.get("mimeType", "image/jpeg")}
                          for c in content if c.get("type") == "image" and c.get("data")]
                if not text and not images and content:
                    text = json.dumps(content)[:4000]
                if attempt == 1 and any(t in text.lower() for t in TRANSIENT):
                    await asyncio.sleep(1.5); continue
                return {"ok": True, "text": text, "images": images, "isError": bool(res.get("isError"))}
        raise BridgeError("tool_error", "unreachable")
