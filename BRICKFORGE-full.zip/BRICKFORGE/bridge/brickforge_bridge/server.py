"""WebSocket protocol between extension/UI and the bridge.

Client -> bridge: ping | status | list_tools | call_tool | restart_mcp | hello
Bridge -> client: pong | status | tools | tool_result | mcp_status | error
Every request carries an `id`; every reply echoes it. Every call_tool gets
exactly one tool_result (ok or structured error)."""
from __future__ import annotations
import asyncio, json, os, time
from collections import OrderedDict

from . import __version__
from .log import log
from .manager import MCPManager
from .mcp_client import BridgeError
from . import studio
from . import cloud
from .ws import serve, WebSocket, WSClosed
import html as _html, urllib.parse as _up

HOST = "127.0.0.1"  # loopback only, by design
PORT = int(os.environ.get("BRICKFORGE_PORT", "17640"))
MAX_TIMEOUT = 600.0



PAGE_CSS = ("body{margin:0;min-height:100vh;display:grid;place-items:center;background:radial-gradient(900px 500px at 50% -10%,#12357466,transparent),#050c1d;color:#EAF2FF;font:16px/1.6 system-ui,Segoe UI,Arial,sans-serif}"
            ".c{max-width:460px;margin:20px;padding:30px;border:1px solid #1b3566;border-radius:18px;background:#0b1a3a;text-align:center;box-shadow:0 0 70px -24px #38bdf8}"
            "h1{margin:10px 0 6px;font-size:24px}p{color:#8fa6cc}a.b{display:inline-block;margin-top:14px;padding:12px 22px;border-radius:12px;background:#38bdf8;color:#04101f;font-weight:700;text-decoration:none;box-shadow:0 0 28px -6px #38bdf8}"
            ".ok{color:#34d399}.er{color:#F87171}code{background:#050c1d;padding:2px 8px;border-radius:6px;border:1px solid #1b3566;word-break:break-all}")


def page(title, body, code=200):
    h = f"<!doctype html><meta charset=utf-8><title>BRICKFORGE</title><style>{PAGE_CSS}</style><div class=c><b style='letter-spacing:.14em'>BRICKFORGE</b>{body}</div>"
    return code, {"Content-Type": "text/html; charset=utf-8"}, h.encode()

class Bridge:
    def __init__(self, mgr: MCPManager):
        self.mgr = mgr
        self.sessions: dict = {}      # ws -> {"role","provider","since"}
        self.started = time.time()
        self.listeners = []           # async callables(event: dict) for history/UI feed

    async def emit(self, ev: dict):
        for l in self.listeners:
            try: await l(ev)
            except Exception as e: log.warning("listener error: %s", e)

    async def status(self) -> dict:
        s = await studio.probe(self.mgr)
        providers = sorted({v["provider"] for v in self.sessions.values() if v.get("provider")})
        return {
            "bridge": True, "version": __version__, "port": PORT,
            "studio_app": s["app"], "place_loaded": s["place"], "tools": len(self.mgr.index),
            "extension_clients": sum(1 for v in self.sessions.values() if v["role"] == "extension"),
            "providers": providers, "servers": self.mgr.health(),
        }

    async def http(self, method, target, hdr):
        """Browser-facing routes. Host must be the loopback address (blocks DNS-rebinding)."""
        host = hdr.get("host", "")
        if host not in (f"127.0.0.1:{PORT}", f"localhost:{PORT}"):
            return 403, {"Content-Type": "text/plain"}, b"Forbidden"
        u = _up.urlparse(target); q = {k: v[0] for k, v in _up.parse_qs(u.query).items()}
        redirect = f"http://127.0.0.1:{PORT}/oauth/callback"
        if method != "GET":
            return 405, {"Content-Type": "text/plain"}, b"GET only"
        if u.path == "/":
            st = cloud.status()
            try: b = await asyncio.wait_for(self.status(), 4)
            except Exception: b = {}
            def row(k, v, c): return f"<p style='margin:4px 0'>{k}: <b class='{c}'>{v}</b></p>"
            diag = (row("Bridge", "running (v" + _html.escape(str(b.get("version", "?"))) + ")", "ok") +
                    row("Roblox Studio", "connected" if b.get("studio_app") else "not connected - open Studio and enable its MCP server", "ok" if b.get("studio_app") else "er") +
                    row("Place loaded", "yes" if b.get("place_loaded") else "no", "ok" if b.get("place_loaded") else "er"))
            who = f"<p class=ok>Connected to Roblox as <b>{_html.escape(str(st.get('username') or st['owner_id']))}</b></p>" if st["linked"] else "<p>Not connected to Roblox yet.</p>"
            return page("", f"<h1>Bridge is running</h1>{diag}<hr style='border:0;border-top:1px solid #1b3566;margin:16px 0'>{who}<a class=b href='/connect'>{'Reconnect' if st['linked'] else 'Connect BRICKFORGE to Roblox'}</a>")
        if u.path == "/connect":
            try:
                return 302, {"Location": cloud.oauth_begin(redirect), "Content-Type": "text/plain"}, b""
            except BridgeError as e:
                extra = ("<p>Open the BRICKFORGE extension &rarr; <b>Roblox link &amp; uploads</b> &rarr; <b>Set up the Roblox app</b> and paste your OAuth app's Client ID.</p>" if e.kind == "no_client_id" else "")
                return page("", f"<h1 class=er>Can't connect yet</h1><p>{_html.escape(e.message)}</p>{extra}", 400)
        if u.path == "/oauth/callback":
            if q.get("error"):
                return page("", f"<h1 class=er>Roblox sign-in was cancelled</h1><p>{_html.escape(q.get('error_description') or q['error'])}</p><a class=b href='/connect'>Try again</a>", 400)
            try:
                st = await asyncio.to_thread(cloud.oauth_finish, q.get("code", ""), q.get("state", ""), redirect)
                await self.emit({"event": "cloud_connected", "user": st.get("owner_id"), "ts": time.time()})
                return page("", f"<h1 class=ok>Connected!</h1><p>BRICKFORGE is linked to <b>{_html.escape(str(st.get('username') or st['owner_id']))}</b>. You can close this tab and go back to your AI chat.</p>")
            except BridgeError as e:
                return page("", f"<h1 class=er>Couldn't finish connecting</h1><p>{_html.escape(e.message)}</p><a class=b href='/connect'>Try again</a>", 400)
        return 404, {"Content-Type": "text/plain"}, b"Not found"

    async def handler(self, ws: WebSocket):
        self.sessions[ws] = {"role": "unknown", "provider": None, "since": time.time()}
        seen: "OrderedDict[str, asyncio.Future]" = OrderedDict()  # per-connection duplicate guard
        log.info("client connected (%s)", ws.peer)
        try:
            await ws.send(json.dumps({"type": "status", **await self.status()}))
            while True:
                try:
                    msg = json.loads(await ws.recv())
                    if not isinstance(msg, dict):
                        raise ValueError
                except WSClosed:
                    raise
                except Exception:
                    await ws.send(json.dumps({"type": "error", "kind": "bad_message", "error": "invalid JSON"}))
                    continue
                t, rid = msg.get("type"), msg.get("id")
                if rid is not None and not isinstance(rid, (str, int)):
                    await ws.send(json.dumps({"type": "error", "kind": "bad_message", "error": "id must be string or int"}))
                    continue
                if t == "ping":
                    await ws.send(json.dumps({"type": "pong", "id": rid}))
                elif t == "hello":
                    self.sessions[ws].update(role=str(msg.get("role", "extension"))[:20], provider=str(msg.get("provider") or "")[:40] or None)
                    await ws.send(json.dumps({"type": "status", "id": rid, **await self.status()}))
                elif t == "status":
                    await ws.send(json.dumps({"type": "status", "id": rid, **await self.status()}))
                elif t == "list_tools":
                    tools = await self.mgr.refresh()
                    await ws.send(json.dumps({"type": "tools", "id": rid, "tools": tools}))
                elif t == "restart_mcp":
                    await self.mgr.restart(msg.get("server"))
                    await ws.send(json.dumps({"type": "mcp_status", "id": rid, "servers": self.mgr.health(), "tools": self.mgr.tools()}))
                elif isinstance(t, str) and t.startswith("cloud_"):
                    await self._cloud(ws, t, rid, msg)
                elif t == "call_tool":
                    asyncio.create_task(self._call(ws, msg, seen))  # off the read loop so pings keep flowing
                else:
                    await ws.send(json.dumps({"type": "error", "id": rid, "kind": "unknown_type", "error": f"unknown message type: {t!r}"}))
        except WSClosed:
            pass
        finally:
            self.sessions.pop(ws, None)
            log.info("client disconnected")

    async def _cloud(self, ws, t, rid, msg):
        # NOTE: never log `msg` here - cloud_link carries the API key.
        async def out(o): await ws.send(json.dumps({"type": "cloud_result", "id": rid, **o}))
        try:
            if t == "cloud_status": res = {"ok": True, **cloud.status()}
            elif t == "cloud_link": res = {"ok": True, **cloud.link(msg.get("key"), msg.get("owner_type"), msg.get("owner_id"))}
            elif t == "cloud_set_client_id": res = {"ok": True, **cloud.set_client_id(msg.get("client_id"))}
            elif t == "cloud_unlink": res = {"ok": True, **cloud.unlink()}
            elif t == "cloud_upload":
                t0 = time.monotonic()
                await self.emit({"event": "cloud_upload_start", "name": msg.get("display_name"), "type": msg.get("asset_type"), "ts": time.time()})
                res = await cloud.upload(msg.get("data"), msg.get("filename"), msg.get("asset_type"), msg.get("display_name"), msg.get("description", ""))
                await self.emit({"event": "cloud_upload_end", "ok": True, "assetId": res.get("assetId"), "ms": int((time.monotonic() - t0) * 1000), "ts": time.time()})
            else: res = {"ok": False, "kind": "unknown_type", "error": f"unknown message type: {t}"}
        except BridgeError as e:
            res = e.to_dict()
            if t == "cloud_upload": await self.emit({"event": "cloud_upload_end", "ok": False, "kind": e.kind, "ts": time.time()})
        except Exception as e:
            res = {"ok": False, "kind": type(e).__name__, "error": str(e)[:200]}
        try: await out(res)
        except WSClosed: pass

    async def _call(self, ws, msg, seen):
        rid, name, args = msg.get("id"), msg.get("name"), msg.get("arguments") or {}
        key = None if rid is None else str(rid)

        async def reply(res: dict):
            try: await ws.send(json.dumps({"type": "tool_result", "id": rid, **res}))
            except WSClosed: pass

        if not isinstance(name, str) or not name or not isinstance(args, dict):
            return await reply(BridgeError("bad_message", "call_tool needs string 'name' and object 'arguments'").to_dict())
        try:
            timeout = min(max(float(msg.get("timeout", 120000)) / 1000.0, 1.0), MAX_TIMEOUT)
        except (TypeError, ValueError):
            timeout = 120.0
        # Duplicate request ids (extension retry / double fire) must not run twice:
        # the second caller just awaits the first execution's result.
        if key is not None and key in seen:
            log.info("duplicate call id %s ignored (re-using result)", key)
            return await reply(await asyncio.shield(seen[key]))
        fut = asyncio.get_running_loop().create_future()
        if key is not None:
            seen[key] = fut
            while len(seen) > 256: seen.popitem(last=False)
        t0 = time.monotonic()
        await self.emit({"event": "call_start", "id": rid, "tool": name, "arguments": args,
                         "provider": self.sessions.get(ws, {}).get("provider"), "ts": time.time()})
        try:
            res = await self.mgr.call(name, args, timeout)
        except BridgeError as e:
            res = e.to_dict()
        except Exception as e:  # never leave the AI waiting
            res = {"ok": False, "kind": type(e).__name__, "error": str(e)}
        fut.set_result(res)
        await self.emit({"event": "call_end", "id": rid, "tool": name, "ok": res.get("ok"),
                         "ms": int((time.monotonic() - t0) * 1000), "result": res, "ts": time.time()})
        await reply(res)


def maybe_open_browser():
    """First-run convenience: open the bridge's own page (served from 127.0.0.1, so no cross-site link problems)."""
    if os.environ.get("BRICKFORGE_NO_BROWSER"):
        return False
    try:
        if cloud.status()["linked"]:
            return False
        import webbrowser
        return bool(webbrowser.open(f"http://127.0.0.1:{PORT}/"))
    except Exception:
        return False


async def run(mgr: MCPManager, bridge: Bridge):
    try:
        server = await serve(bridge.handler, HOST, PORT, http=bridge.http)
    except OSError as e:
        raise SystemExit(f"Port {PORT} is already in use ({e}). Another BRICKFORGE bridge may be running - "
                         f"close it, or set BRICKFORGE_PORT to a different port.")
    log.info("BRICKFORGE bridge v%s listening on ws://%s:%d", __version__, HOST, PORT)
    log.info("READY. To connect Roblox, open  http://127.0.0.1:%d  in your browser (it should open by itself).", PORT)
    asyncio.get_running_loop().call_later(0.7, maybe_open_browser)
    asyncio.create_task(mgr.start_all())  # socket is up first; Studio may be slow/absent
    mgr.watch_task = asyncio.create_task(mgr.watch(float(os.environ.get("BRICKFORGE_WATCH", "5"))))
    async with server:
        await server.serve_forever()
