"""Studio connectivity, as separate honest levels (never one fake 'connected')."""
from __future__ import annotations
import json
from .manager import MCPManager

NO_PLACE = ("doesn't have a place", "no place opened", "place opened", "has disconnected", "no active studio")


async def _probe(mgr: MCPManager, tool: str):
    ent = mgr.index.get(tool)
    if not ent:
        return None
    c, real = ent
    if c._call_lock.locked():  # never queue a probe behind a long tool call
        return None
    try:
        async with c._call_lock:
            r = await c._request("tools/call", {"name": real, "arguments": {}}, 8)
        if r.get("error"):
            return None
        return "\n".join(x.get("text", "") for x in r.get("result", {}).get("content", []) if x.get("type") == "text")
    except Exception:
        return None


async def probe(mgr: MCPManager, server_id: str = "roblox") -> dict:
    """app/place are True / False / None (None = unknown, e.g. probe busy)."""
    c = mgr.clients.get(server_id)
    if c is None:
        return {"app": None, "place": None, "tools": 0}
    if not c.alive():
        return {"app": False, "place": False, "tools": 0}  # MCP server not running = Studio can't be attached
    if not c.tools:
        return {"app": False, "place": False, "tools": 0}  # StudioMCP lists 0 tools until Studio attaches
    text = await _probe(mgr, "list_roblox_studios")
    if text is None:
        return {"app": None, "place": None, "tools": len(c.tools)}
    try:
        studios = json.loads(text).get("studios") or []
    except Exception:
        return {"app": None, "place": None, "tools": len(c.tools)}
    if not studios:
        return {"app": False, "place": False, "tools": len(c.tools)}
    st = await _probe(mgr, "get_studio_state")
    if st is None:
        return {"app": True, "place": None, "tools": len(c.tools)}
    return {"app": True, "place": not any(m in st.lower() for m in NO_PLACE), "tools": len(c.tools)}
