"""Minimal RFC 6455 WebSocket server on asyncio (no third-party deps).

Only what the bridge needs: text frames, fragmentation, ping/pong, close,
Origin allow-listing and message size limits.
"""
from __future__ import annotations
import asyncio, base64, hashlib, struct
from typing import Awaitable, Callable, Optional

GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
MAX_MESSAGE = 32 * 1024 * 1024  # screenshots arrive as base64


class WSClosed(Exception):
    pass


class WebSocket:
    def __init__(self, reader, writer, peer):
        self.reader, self.writer, self.peer = reader, writer, peer
        self.closed = False
        self._send_lock = asyncio.Lock()

    async def _frame(self, opcode: int, payload: bytes):
        n = len(payload)
        head = bytes([0x80 | opcode])
        if n < 126:
            head += bytes([n])
        elif n < 65536:
            head += b"\x7e" + struct.pack(">H", n)
        else:
            head += b"\x7f" + struct.pack(">Q", n)
        async with self._send_lock:
            if self.closed:
                raise WSClosed()
            try:
                self.writer.write(head + payload)
                await self.writer.drain()
            except (ConnectionError, OSError):
                self.closed = True
                raise WSClosed()

    async def send(self, text: str):
        await self._frame(0x1, text.encode("utf-8"))

    async def close(self, code: int = 1000):
        if not self.closed:
            try:
                await self._frame(0x8, struct.pack(">H", code))
            except WSClosed:
                pass
            self.closed = True
            try:
                self.writer.close()
            except Exception:
                pass

    async def recv(self) -> str:
        """Return next text message; raise WSClosed on close."""
        buf, text_mode = b"", True
        while True:
            try:
                h = await self.reader.readexactly(2)
                fin, opcode = h[0] & 0x80, h[0] & 0x0F
                masked, ln = h[1] & 0x80, h[1] & 0x7F
                if ln == 126:
                    ln = struct.unpack(">H", await self.reader.readexactly(2))[0]
                elif ln == 127:
                    ln = struct.unpack(">Q", await self.reader.readexactly(8))[0]
                if ln > MAX_MESSAGE or len(buf) + ln > MAX_MESSAGE:
                    await self.close(1009)
                    raise WSClosed()
                if not masked:  # clients MUST mask
                    await self.close(1002)
                    raise WSClosed()
                mask = await self.reader.readexactly(4)
                data = bytearray(await self.reader.readexactly(ln))
            except (asyncio.IncompleteReadError, ConnectionError, OSError):
                self.closed = True
                raise WSClosed()
            for i in range(len(data)):
                data[i] ^= mask[i & 3]
            if opcode == 0x8:
                await self.close()
                raise WSClosed()
            if opcode == 0x9:
                await self._frame(0xA, bytes(data))
                continue
            if opcode == 0xA:
                continue
            if opcode in (0x1, 0x2):
                buf, text_mode = bytes(data), opcode == 0x1
            elif opcode == 0x0:
                buf += bytes(data)
            if fin:
                if not text_mode:
                    continue
                return buf.decode("utf-8", errors="replace")


def _default_origin_ok(origin: Optional[str]) -> bool:
    # No Origin = non-browser local client. Extensions send chrome-extension://...
    # Ordinary web pages (https://chatgpt.com, evil.example) are REJECTED so a
    # website can never drive Roblox Studio through the bridge.
    if not origin:
        return True
    return origin.startswith(("chrome-extension://", "moz-extension://", "http://127.0.0.1", "http://localhost"))


async def serve(handler: Callable[[WebSocket], Awaitable[None]], host: str, port: int,
                origin_ok: Callable[[Optional[str]], bool] = _default_origin_ok, http=None):
    async def on_conn(reader, writer):
        peer = writer.get_extra_info("peername")
        try:
            raw = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 10)
        except Exception:
            writer.close(); return
        lines = raw.decode("latin-1").split("\r\n")
        hdr = {}
        for l in lines[1:]:
            if ":" in l:
                k, v = l.split(":", 1); hdr[k.strip().lower()] = v.strip()
        key = hdr.get("sec-websocket-key")
        if hdr.get("upgrade", "").lower() != "websocket" or not key:
            code, rh, body = 400, {}, b""
            if http is not None:
                try:
                    method, target = lines[0].split(" ")[:2]
                    code, rh, body = await http(method, target, hdr)
                except Exception:
                    code, rh, body = 500, {"Content-Type": "text/plain"}, b"Internal error"
            reason = {200: "OK", 302: "Found", 400: "Bad Request", 403: "Forbidden", 404: "Not Found", 405: "Method Not Allowed", 500: "Internal Server Error"}.get(code, "OK")
            head = f"HTTP/1.1 {code} {reason}\r\nContent-Length: {len(body)}\r\nConnection: close\r\nCache-Control: no-store\r\n"
            head += "".join(f"{k}: {v}\r\n" for k, v in rh.items()) + "\r\n"
            writer.write(head.encode("latin-1") + body)
            await writer.drain(); writer.close(); return
        if not origin_ok(hdr.get("origin")):
            writer.write(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
            await writer.drain(); writer.close(); return
        acc = base64.b64encode(hashlib.sha1(key.encode() + GUID).digest()).decode()
        writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n"
                      f"Connection: Upgrade\r\nSec-WebSocket-Accept: {acc}\r\n\r\n").encode())
        await writer.drain()
        ws = WebSocket(reader, writer, peer)
        try:
            await handler(ws)
        finally:
            await ws.close()

    return await asyncio.start_server(on_conn, host, port, limit=2 ** 20)
