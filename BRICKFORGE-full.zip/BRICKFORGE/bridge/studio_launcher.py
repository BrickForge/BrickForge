"""Finds the live StudioMCP binary and runs it, forwarding stdio.

Roblox's own mcp.bat hard-codes one Studio version folder and breaks after an
auto-update. We scan all version folders instead and prefer ones that still
contain a real Studio executable (leftover 'zombie' folders are last resort).
Override: set BRICKFORGE_STUDIO_MCP_PATH to a file or folder."""
import os, subprocess, sys
from pathlib import Path

ENV = "BRICKFORGE_STUDIO_MCP_PATH"
WIN_STUDIO = ("RobloxStudioBeta.exe", "RobloxStudio.exe")
MAC_STUDIO = ("RobloxStudio", "RobloxStudioBeta", "Roblox")


def _newest(paths):
    try:
        return max(paths, key=lambda p: p.stat().st_mtime)
    except (ValueError, OSError):
        return None


def _win():
    roots = [Path(os.environ[k]) / "Roblox" / "Versions" for k in ("LOCALAPPDATA", "ProgramFiles", "ProgramFiles(x86)") if os.environ.get(k)]
    paired, orphan = [], []
    for r in roots:
        if r.is_dir():
            for d in r.iterdir():
                m = d / "StudioMCP.exe"
                if d.is_dir() and m.is_file():
                    (paired if any((d / e).is_file() for e in WIN_STUDIO) else orphan).append(m)
    return _newest(paired) or _newest(orphan)


def _mac():
    home = Path.home()
    for app in ("RobloxStudio", "Roblox", "RobloxStudioBeta"):
        for base in (Path("/Applications"), home / "Applications"):
            d = base / f"{app}.app" / "Contents" / "MacOS"
            if (d / "StudioMCP").is_file() and any((d / e).is_file() for e in MAC_STUDIO):
                return d / "StudioMCP"


def find():
    ov = os.environ.get(ENV)
    if ov:
        p = Path(ov).expanduser()
        if p.is_dir():
            p = p / ("Contents/MacOS/StudioMCP" if sys.platform == "darwin" else "StudioMCP.exe")
        if p.is_file():
            return p
        sys.stderr.write(f"studio_launcher: {ENV} does not point to a StudioMCP binary: {ov}\n")
    return _mac() if sys.platform == "darwin" else _win()


def main():
    exe = find()
    if not exe:
        sys.stderr.write("studio_launcher: StudioMCP not found. Open Roblox Studio and enable "
                         "'Studio as MCP server' (Assistant > ... > Manage MCP Servers).\n")
        return 1
    sys.stderr.write(f"studio_launcher: using {exe}\n"); sys.stderr.flush()
    p = subprocess.Popen([str(exe)] + sys.argv[1:])
    try:
        return p.wait()
    except KeyboardInterrupt:
        p.terminate(); return p.wait()


if __name__ == "__main__":
    sys.exit(main())
