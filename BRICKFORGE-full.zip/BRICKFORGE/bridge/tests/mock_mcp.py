"""Tiny fake MCP server (stdio) emulating StudioMCP's behaviour for bridge tests."""
import json, sys, time, os
STUDIO_UP = os.environ.get("MOCK_STUDIO", "1") == "1"
def out(o): sys.stdout.write(json.dumps(o) + "\n"); sys.stdout.flush()
TOOLS = [{"name": n, "description": n, "inputSchema": {"type": "object"}} for n in
         ("list_roblox_studios", "get_studio_state", "echo", "slow", "boom", "die")]
for line in sys.stdin:
    m = json.loads(line); mid = m.get("id"); meth = m.get("method")
    if mid is None: continue
    if meth == "initialize": out({"jsonrpc": "2.0", "id": mid, "result": {"protocolVersion": "2024-11-05", "capabilities": {}, "serverInfo": {"name": "mock"}}})
    elif meth == "tools/list": out({"jsonrpc": "2.0", "id": mid, "result": {"tools": TOOLS if STUDIO_UP else []}})
    elif meth == "tools/call":
        n, a = m["params"]["name"], m["params"]["arguments"]
        def ok(t): out({"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": t}]}})
        if n == "list_roblox_studios": ok(json.dumps({"studios": [{"name": "Place1", "active": True}]}))
        elif n == "get_studio_state": ok("Available DataModels: Edit")
        elif n == "echo": ok("echo:" + str(a.get("v")))
        elif n == "slow": time.sleep(float(a.get("s", 1))); ok("slow:" + str(a.get("v")))
        elif n == "boom": out({"jsonrpc": "2.0", "id": mid, "error": {"code": -1, "message": "kaboom"}})
        elif n == "die": os._exit(3)
