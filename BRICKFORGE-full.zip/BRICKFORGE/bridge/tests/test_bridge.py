import os as _o; _o.environ['BRICKFORGE_NO_BROWSER']='1'
import asyncio, base64, json, os, struct, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
cfg = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False)
json.dump({"mcpServers": {"roblox": {"command": os.path.join(HERE, "mock_mcp.py"), "args": []}}}, cfg); cfg.close()
os.environ["BRICKFORGE_CONFIG"] = cfg.name
os.environ["BRICKFORGE_HOME"] = tempfile.mkdtemp(); os.environ["BRICKFORGE_PORT"] = "17999"; os.environ["BRICKFORGE_WATCH"] = "0.5"
from brickforge_bridge import server, log as logmod
from brickforge_bridge.manager import MCPManager
logmod.setup(tempfile.mkdtemp())

class Client:
    async def connect(self, origin=None):
        self.r, self.w = await asyncio.open_connection("127.0.0.1", 17999)
        key = base64.b64encode(os.urandom(16)).decode()
        req = f"GET / HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n"
        if origin: req += f"Origin: {origin}\r\n"
        self.w.write((req + "\r\n").encode()); await self.w.drain()
        head = await self.r.readuntil(b"\r\n\r\n")
        return head.split(b"\r\n")[0].decode()
    async def send(self, o, raw=None):
        p = (raw if raw is not None else json.dumps(o)).encode(); m = os.urandom(4)
        n = len(p); h = b"\x81" + (bytes([0x80 | n]) if n < 126 else b"\xfe" + struct.pack(">H", n) if n < 65536 else b"\xff" + struct.pack(">Q", n))
        self.w.write(h + m + bytes(b ^ m[i & 3] for i, b in enumerate(p))); await self.w.drain()
    async def recv(self):
        h = await self.r.readexactly(2); n = h[1] & 0x7F
        if n == 126: n = struct.unpack(">H", await self.r.readexactly(2))[0]
        elif n == 127: n = struct.unpack(">Q", await self.r.readexactly(8))[0]
        return json.loads(await self.r.readexactly(n))
    async def until(self, typ, rid=None):
        while True:
            m = await asyncio.wait_for(self.recv(), 20)
            if m.get("type") == typ and (rid is None or m.get("id") == rid): return m

results = []
def check(name, cond, extra=""):
    results.append(cond); print(("PASS " if cond else "FAIL ") + name + (f"  {extra}" if not cond else ""))

async def main():
    mgr = MCPManager(); mgr.load_config(); br = server.Bridge(mgr); events = []
    async def lst(ev): events.append(ev)
    br.listeners.append(lst)
    task = asyncio.create_task(server.run(mgr, br)); await asyncio.sleep(0.3)

    bad = Client(); check("web-page Origin rejected (403)", "403" in await bad.connect("https://chatgpt.com"))
    c = Client(); check("extension Origin accepted", "101" in await c.connect("chrome-extension://abc"))
    await c.until("status")
    await c.send({"type": "hello", "id": "h", "role": "extension", "provider": "claude"})
    st = await c.until("status", "h")
    check("provider shown in status", st["providers"] == ["claude"])
    for _ in range(40):
        await c.send({"type": "list_tools", "id": "lt"}); tl = await c.until("tools", "lt")
        if tl["tools"]: break
        await asyncio.sleep(0.5)
    check("dynamic tool discovery", {t["name"] for t in tl["tools"]} >= {"echo", "boom"}, str([t["name"] for t in tl["tools"]]))
    await c.send({"type": "status", "id": "s"}); st = await c.until("status", "s")
    check("studio app + place detected via 2-level probe", st["studio_app"] is True and st["place_loaded"] is True, str(st))

    await c.send({"type": "ping", "id": 1}); check("ping/pong", (await c.until("pong", 1))["id"] == 1)
    await c.send({"type": "call_tool", "id": "e1", "name": "echo", "arguments": {"v": "hi"}})
    r = await c.until("tool_result", "e1"); check("tool call returns result", r["ok"] and r["text"] == "echo:hi", str(r))

    for i in range(8): await c.send({"type": "call_tool", "id": f"c{i}", "name": "echo", "arguments": {"v": i}})
    got = {}
    for _ in range(8):
        m = await c.until("tool_result"); got[m["id"]] = m["text"]
    check("8 concurrent calls each get their OWN result", all(got[f"c{i}"] == f"echo:{i}" for i in range(8)), str(got))

    await c.send({"type": "call_tool", "id": "b", "name": "boom", "arguments": {}})
    r = await c.until("tool_result", "b"); check("tool error -> structured error", r["ok"] is False and r["kind"] == "tool_error" and "kaboom" in r["error"], str(r))
    await c.send({"type": "call_tool", "id": "u", "name": "nope", "arguments": {}})
    r = await c.until("tool_result", "u"); check("unknown tool -> structured error", r["kind"] == "unknown_tool")
    await c.send({"type": "call_tool", "id": "t", "name": "slow", "arguments": {"s": 3}, "timeout": 1000})
    r = await c.until("tool_result", "t"); check("timeout -> structured error (no hang)", r["ok"] is False and r["kind"] == "timeout", str(r))
    await c.send({"type": "ping", "id": 2}); await c.until("pong", 2)  # still alive; late reply must not poison next call
    await asyncio.sleep(2.5)
    await c.send({"type": "call_tool", "id": "after", "name": "echo", "arguments": {"v": "ok"}})
    r = await c.until("tool_result", "after"); check("late reply after timeout does not leak into next call", r["text"] == "echo:ok", str(r))

    n0 = sum(1 for e in events if e["event"] == "call_start")
    await c.send({"type": "call_tool", "id": "dup", "name": "echo", "arguments": {"v": "d"}})
    await c.send({"type": "call_tool", "id": "dup", "name": "echo", "arguments": {"v": "d"}})
    a = await c.until("tool_result", "dup"); b = await c.until("tool_result", "dup")
    n1 = sum(1 for e in events if e["event"] == "call_start")
    check("duplicate call id executes once", n1 - n0 == 1 and a["text"] == b["text"], f"{n1-n0}")

    await c.send(None, raw="{not json"); check("invalid JSON -> error, connection survives", (await c.until("error"))["kind"] == "bad_message")
    await c.send({"type": "call_tool", "id": "x", "name": 5, "arguments": {}})
    check("bad call_tool args rejected", (await c.until("tool_result", "x"))["kind"] == "bad_message")

    await c.send({"type": "call_tool", "id": "d1", "name": "die", "arguments": {}})
    r = await c.until("tool_result", "d1")
    check("server crash mid-call -> reply, not hang", r["ok"] is False or "die" in str(r), str(r))
    await asyncio.sleep(1)
    await c.send({"type": "call_tool", "id": "rec", "name": "echo", "arguments": {"v": "back"}})
    r = await c.until("tool_result", "rec"); check("auto-recovery: next call works after crash", r["ok"] and r["text"] == "echo:back", str(r))
    check("history events emitted", any(e["event"] == "call_end" for e in events))
    KEY = "rbx-" + "Q9w8E7r6" * 6
    await c.send({"type": "cloud_link", "id": "cl", "key": KEY, "owner_type": "user", "owner_id": "99"})
    r = await c.until("cloud_result", "cl"); check("cloud_link over WS ok, reply never contains the key", r["ok"] and r["linked"] and KEY not in json.dumps(r), str(r))
    await c.send({"type": "cloud_status", "id": "cs"}); r = await c.until("cloud_result", "cs"); check("cloud_status over WS masks key", r["linked"] and KEY not in json.dumps(r))
    await c.send({"type": "cloud_upload", "id": "cu", "data": "!!", "filename": "a.png", "asset_type": "Decal", "display_name": "x"})
    r = await c.until("cloud_result", "cu"); check("cloud_upload with bad data -> structured error", r["ok"] is False and r["kind"] == "bad_input", str(r))
    await c.send({"type": "cloud_unlink", "id": "cx"}); r = await c.until("cloud_result", "cx"); check("cloud_unlink over WS", r["linked"] is False)
    # watchdog: kill the server with NO call pending; it must come back on its own
    await mgr.clients["roblox"].stop(); mgr.rebuild()
    check("tools disappear from index while server is down", len(mgr.index) == 0)
    check("status reports Studio NOT connected when MCP server is down", (await (br.status()))["studio_app"] is False)
    for _ in range(40):
        if mgr.clients["roblox"].alive() and mgr.index: break
        await asyncio.sleep(0.5)
    check("watchdog revives dead server + tools without any call", mgr.clients["roblox"].alive() and "echo" in mgr.index)
    task.cancel(); mgr.watch_task.cancel(); await mgr.shutdown()


asyncio.run(main())
print(f"\n{sum(results)}/{len(results)} passed"); sys.exit(0 if all(results) else 1)
