import os as _o; _o.environ['BRICKFORGE_NO_BROWSER']='1'
import asyncio, base64, email, json, os, sys, tempfile, threading, glob
from http.server import BaseHTTPRequestHandler, HTTPServer
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE))
home = tempfile.mkdtemp(); os.environ["BRICKFORGE_HOME"] = home
GOOD = "rbx-" + "A1b2C3d4" * 6
seen = {"polls": 0, "last": None}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, o):
        b = json.dumps(o).encode(); self.send_response(code); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_POST(self):
        if self.headers.get("x-api-key") != GOOD: return self._send(401, {"message": "bad key"})
        raw = self.rfile.read(int(self.headers["Content-Length"]))
        msg = email.message_from_bytes(b"Content-Type: " + self.headers["Content-Type"].encode() + b"\r\n\r\n" + raw)
        parts = {p.get_param("name", header="content-disposition"): p for p in msg.get_payload()}
        req = json.loads(parts["request"].get_payload(decode=True)); f = parts["fileContent"]
        seen["last"] = {"req": req, "ctype": f.get_content_type(), "body": f.get_payload(decode=True)}
        if req["displayName"] == "FORBIDDEN": return self._send(403, {"message": "nope"})
        seen["polls"] = 0; self._send(200, {"path": "operations/op-" + ("fail" if req["displayName"] == "FAIL" else "123"), "done": False})
    def do_GET(self):
        if self.headers.get("x-api-key") != GOOD: return self._send(401, {})
        seen["polls"] += 1
        if "fail" in self.path: return self._send(200, {"path": "operations/op-fail", "done": True, "error": {"message": "image too large"}})
        if seen["polls"] < 3: return self._send(200, {"path": "operations/op-123", "done": False})
        self._send(200, {"path": "operations/op-123", "done": True, "response": {"assetId": "2205400862", "displayName": "Coin", "moderationResult": {"moderationState": "MODERATION_STATE_APPROVED"}}})
srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
os.environ["BRICKFORGE_CLOUD_URL"] = f"http://127.0.0.1:{srv.server_port}"
from brickforge_bridge import cloud, log as logmod
logdir = tempfile.mkdtemp(); logmod.setup(logdir)
R = []
def check(n, c, x=""): R.append(c); print(("PASS " if c else "FAIL ") + n + (f"  {x}" if not c else ""))
def err(coro_or_fn):
    try: r = coro_or_fn(); return asyncio.run(r) if asyncio.iscoroutine(r) else r
    except Exception as e: return getattr(e, "kind", type(e).__name__)
b64 = lambda b: base64.b64encode(b).decode()
PNG = b"\x89PNG\r\n\x1a\n" + b"x" * 100

check("starts unlinked", cloud.status()["linked"] is False)
check("not linked -> clear error", err(lambda: cloud.upload(b64(PNG), "a.png", "Decal", "Coin")) == "not_linked")
check("rejects non-numeric owner id", err(lambda: cloud.link(GOOD, "user", "abc")) == "bad_input")
check("rejects junk key", err(lambda: cloud.link("short", "user", "123")) == "bad_input")
check("rejects key with spaces", err(lambda: cloud.link("a b " * 10, "user", "123")) == "bad_input")
st = cloud.link(GOOD, "user", "4242")
check("link ok; status shows only last 4", st["linked"] and st["key_hint"] == "ends in " + GOOD[-4:] and GOOD not in json.dumps(st))
files = glob.glob(home + "/*")
check("secret file exists, owner-only perms", len(files) == 1 and (sys.platform == "win32" or oct(os.stat(files[0]).st_mode & 0o777) == "0o600"))
check("status never contains the key", GOOD not in json.dumps(cloud.status()))

r = asyncio.run(cloud.upload(b64(PNG), "coin.png", "Decal", "Coin", "a coin", poll_seconds=20))
check("upload -> polls operation -> assetId", r["ok"] and r["assetId"] == "2205400862" and r["rbxassetid"] == "rbxassetid://2205400862" and r["moderation"] == "Approved", str(r))
L = seen["last"]
check("request matches Roblox API shape (type, name, creator, content-type, bytes)", L["req"]["assetType"] == "Decal" and L["req"]["displayName"] == "Coin" and L["req"]["creationContext"] == {"creator": {"userId": "4242"}} and L["ctype"] == "image/png" and L["body"] == PNG, str(L["req"]))
cloud.link(GOOD, "group", "777"); asyncio.run(cloud.upload(b64(PNG), "c.png", "Decal", "G", poll_seconds=20))
check("group owner sends groupId", seen["last"]["req"]["creationContext"] == {"creator": {"groupId": "777"}})
check("wrong extension for type rejected locally", err(lambda: cloud.upload(b64(PNG), "x.mp3", "Decal", "X")) == "bad_type")
check("unsupported type rejected", err(lambda: cloud.upload(b64(PNG), "x.png", "Plugin", "X")) == "bad_type")
check("empty name rejected", err(lambda: cloud.upload(b64(PNG), "x.png", "Decal", "  ")) == "bad_input")
check("over 20MB rejected before any network call", err(lambda: cloud.upload(b64(b"x" * (20 * 1024 * 1024 + 1)), "x.png", "Decal", "Big")) == "too_large")
check("403 -> permission hint", err(lambda: cloud.upload(b64(PNG), "x.png", "Decal", "FORBIDDEN")) == "http_403")
check("Roblox-side failure surfaces its reason", err(lambda: cloud.upload(b64(PNG), "x.png", "Decal", "FAIL", poll_seconds=20)) == "upload_failed")
cloud.link("rbx-" + "Z" * 40, "user", "1")
check("bad key -> 401 with helpful message", err(lambda: cloud.upload(b64(PNG), "x.png", "Decal", "Coin")) == "http_401")
check("timeout while processing -> 'pending', not a hang", err(lambda: cloud.upload(b64(PNG), "x.png", "Decal", "Coin", poll_seconds=0.1)) in ("pending", "http_401"))
check("no key/PII in any log file", not any(GOOD in open(f, errors="ignore").read() for f in glob.glob(logdir + "/*")))
cloud.unlink(); check("unlink removes secret", cloud.status()["linked"] is False and not glob.glob(home + "/*"))
print(f"\n{sum(R)}/{len(R)} passed"); sys.exit(0 if all(R) else 1)
