import os as _o; _o.environ['BRICKFORGE_NO_BROWSER']='1'
import asyncio, base64, email, hashlib, http.client, json, os, sys, tempfile, threading, urllib.parse as up, glob
from http.server import BaseHTTPRequestHandler, HTTPServer
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE))
home = tempfile.mkdtemp(); os.environ["BRICKFORGE_HOME"] = home; os.environ["BRICKFORGE_PORT"] = "17998"; os.environ["BRICKFORGE_WATCH"] = "30"
os.environ.pop("BRICKFORGE_OAUTH_CLIENT_ID", None)
cfg = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False); json.dump({"mcpServers": {}}, cfg); cfg.close(); os.environ["BRICKFORGE_CONFIG"] = cfg.name
M = {"challenge": None, "pkce_ok": False, "refreshes": 0, "revoked": 0, "at": "AT1", "rt": "RT1", "fail_refresh": False, "creator": None, "auth_seen": None, "polls": 0}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _j(self, code, o): b = json.dumps(o).encode(); self.send_response(code); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_POST(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        if self.path == "/oauth/v1/token":
            f = {k: v[0] for k, v in up.parse_qs(raw.decode()).items()}
            if f.get("grant_type") == "authorization_code":
                chal = base64.urlsafe_b64encode(hashlib.sha256(f.get("code_verifier", "").encode()).digest()).rstrip(b"=").decode()
                M["pkce_ok"] = chal == M["challenge"] and "client_secret" not in f and f.get("client_id") == "123456789"
                if f.get("code") != "GOODCODE" or not M["pkce_ok"]: return self._j(400, {"error": "invalid_grant"})
                return self._j(200, {"access_token": M["at"], "refresh_token": M["rt"], "token_type": "Bearer", "expires_in": 900})
            if f.get("grant_type") == "refresh_token":
                if M["fail_refresh"] or f.get("refresh_token") != M["rt"]: return self._j(400, {"error": "invalid_grant"})
                M["refreshes"] += 1; M["at"], M["rt"] = f"AT{M['refreshes']+1}", f"RT{M['refreshes']+1}"
                return self._j(200, {"access_token": M["at"], "refresh_token": M["rt"], "expires_in": 900})
        if self.path == "/oauth/v1/token/revoke": M["revoked"] += 1; return self._j(200, {})
        if self.path == "/assets/v1/assets":
            M["auth_seen"] = self.headers.get("Authorization")
            if M["auth_seen"] != "Bearer " + M["at"]: return self._j(401, {})
            msg = email.message_from_bytes(b"Content-Type: " + self.headers["Content-Type"].encode() + b"\r\n\r\n" + raw)
            parts = {p.get_param("name", header="content-disposition"): p for p in msg.get_payload()}
            M["creator"] = json.loads(parts["request"].get_payload(decode=True))["creationContext"]["creator"]; M["polls"] = 0
            return self._j(200, {"path": "operations/op1", "done": False})
        self._j(404, {})
    def do_GET(self):
        if self.path == "/oauth/v1/userinfo":
            if self.headers.get("Authorization") != "Bearer " + M["at"]: return self._j(401, {})
            return self._j(200, {"sub": "555", "preferred_username": "ZitroLee"})
        if self.path.startswith("/assets/v1/operations/"):
            M["polls"] += 1
            return self._j(200, {"done": M["polls"] > 1, "response": {"assetId": "777", "displayName": "Coin", "moderationResult": {"moderationState": "MODERATION_STATE_APPROVED"}}} if M["polls"] > 1 else {"done": False})
        self._j(404, {})
srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
os.environ["BRICKFORGE_CLOUD_URL"] = f"http://127.0.0.1:{srv.server_port}"
from brickforge_bridge import server, cloud, log as logmod
from brickforge_bridge.manager import MCPManager
logdir = tempfile.mkdtemp(); logmod.setup(logdir)
R = []
def check(n, c, x=""): R.append(c); print(("PASS " if c else "FAIL ") + n + (f"  {x}" if not c else ""))
def get(path, host="127.0.0.1:17998", method="GET"):
    c = http.client.HTTPConnection("127.0.0.1", 17998, timeout=10); c.request(method, path, headers={"Host": host}); r = c.getresponse()
    return r.status, dict(r.getheaders()), r.read().decode()
PNG = base64.b64encode(b"\x89PNG" + b"x" * 50).decode()

async def main():
    mgr = MCPManager(); mgr.load_config(); br = server.Bridge(mgr); t = asyncio.create_task(server.run(mgr, br)); await asyncio.sleep(0.4)
    A = lambda *a, **k: asyncio.to_thread(get, *a, **k)
    code, h, b = await A("/connect"); check("/connect without Client ID -> friendly setup page (no crash)", code == 400 and "Client ID" in b and "Set up the Roblox app" in b, b[:200])
    os.environ["BRICKFORGE_OAUTH_CLIENT_ID"] = "123456789"
    code, h, b = await A("/connect"); loc = h.get("Location", ""); q = {k: v[0] for k, v in up.parse_qs(up.urlparse(loc).query).items()}
    check("/connect redirects to Roblox's authorize page", code == 302 and up.urlparse(loc).path == "/oauth/v1/authorize", loc)
    check("authorize URL: client_id, S256 PKCE, redirect, scopes, state", q.get("client_id") == "123456789" and q.get("code_challenge_method") == "S256" and q.get("response_type") == "code"
          and q.get("redirect_uri") == "http://127.0.0.1:17998/oauth/callback" and {"asset:read", "asset:write", "openid"} <= set(q.get("scope", "").split()) and len(q.get("state", "")) >= 20 and len(q.get("code_challenge", "")) >= 40, str(q))
    M["challenge"] = q["code_challenge"]; state = q["state"]
    check("DNS-rebinding guard: foreign Host header -> 403", (await A("/connect", host="evil.com"))[0] == 403)
    check("only GET allowed", (await A("/connect", method="POST"))[0] == 405)
    code, _, b = await A("/oauth/callback?code=GOODCODE&state=WRONG"); st = cloud.status()
    check("callback with wrong state rejected, nothing linked", code == 400 and not st["linked"], b[:100])
    code, _, b = await A("/oauth/callback?error=access_denied&error_description=user+said+no"); check("user cancels on Roblox -> clear page", code == 400 and "cancelled" in b)
    code, _, b = await A(f"/oauth/callback?code=GOODCODE&state={state}"); st = cloud.status()
    check("good callback: PKCE verified by (fake) Roblox, token exchanged", M["pkce_ok"] and code == 200 and "Connected!" in b, b[:200])
    check("linked as the Roblox user (name + id), mode oauth", st["linked"] and st["mode"] == "oauth" and st["owner_id"] == "555" and st["username"] == "ZitroLee", str(st))
    check("status/page never expose tokens", "AT1" not in json.dumps(st) and "RT1" not in json.dumps(st) and "RT1" not in b)
    check("state is single-use (replay rejected)", (await A(f"/oauth/callback?code=GOODCODE&state={state}"))[0] == 400)
    check("home page shows connected user", "ZitroLee" in (await A("/"))[2])
    r = await cloud.upload(PNG, "coin.png", "Decal", "Coin", poll_seconds=20)
    check("upload uses Bearer token + creator = the connected user", r["ok"] and M["auth_seen"] == "Bearer AT1" and M["creator"] == {"userId": "555"}, f"{r} {M}")
    sec = cloud._load(); sec["expires_at"] = 0; cloud._save(sec)
    r = await cloud.upload(PNG, "coin.png", "Decal", "Coin2", poll_seconds=20)
    check("expired access token refreshed automatically, rotated token stored", r["ok"] and M["refreshes"] == 1 and M["auth_seen"] == "Bearer AT2" and cloud._load()["refresh_token"] == "RT2")
    sec = cloud._load(); sec["expires_at"] = 0; cloud._save(sec); M["fail_refresh"] = True
    try: await cloud.upload(PNG, "coin.png", "Decal", "Coin3", poll_seconds=5); k = "none"
    except Exception as e: k = getattr(e, "kind", "?")
    check("revoked/expired Roblox login -> 'reconnect' error (not a hang)", k == "reconnect", k)
    M["fail_refresh"] = False
    cloud.unlink(); check("unlink revokes the token at Roblox and deletes local copy", M["revoked"] == 1 and not cloud.status()["linked"] and not glob.glob(home + "/roblox_link.bin"))
    blob = "".join(open(f, errors="ignore").read() for f in glob.glob(logdir + "/*"))
    check("no tokens or codes in logs", not any(x in blob for x in ("AT1", "AT2", "RT1", "RT2", "GOODCODE")))
    # first-run auto-open of the bridge's own page
    import webbrowser; opened = []; real = webbrowser.open; webbrowser.open = lambda u: (opened.append(u), True)[1]; os.environ.pop("BRICKFORGE_NO_BROWSER")
    check("unlinked -> bridge opens its own page on start", server.maybe_open_browser() and opened == ["http://127.0.0.1:17998/"], str(opened))
    cloud.link("rbx-" + "Z" * 30, "user", "1"); opened.clear()
    check("already linked -> does not open the browser again", not server.maybe_open_browser() and not opened)
    os.environ["BRICKFORGE_NO_BROWSER"] = "1"; cloud.unlink(); webbrowser.open = real
    code, _, b = await A("/"); check("home page shows live bridge + Studio status", code == 200 and "Bridge" in b and "Roblox Studio" in b and "Connect BRICKFORGE to Roblox" in b)
    t.cancel(); mgr.watch_task.cancel()
asyncio.run(main()); print(f"\n{sum(R)}/{len(R)} passed"); sys.exit(0 if all(R) else 1)
