// Adapter registry + shared DOM helpers. One adapter per provider; a site update only breaks one file.
window.BF = window.BF || { adapters: {} };
BF.register = (a) => { BF.adapters[a.id] = a; };
BF.q = (sels, root = document) => { for (const s of sels) { try { const el = root.querySelector(s); if (el) return el; } catch {} } return null; };
BF.qa = (sels, root = document) => { for (const s of sels) { try { const l = root.querySelectorAll(s); if (l.length) return [...l]; } catch {} } return []; };
BF.visible = (el) => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
BF.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// Robust composer fill: execCommand first (works with ProseMirror/Quill/Lexical), paste-event fallback, textarea fallback.
BF.setText = async (el, text) => {
  el.focus();
  if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
    const set = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), "value").set; set.call(el, text);
    el.dispatchEvent(new Event("input", { bubbles: true })); return true;
  }
  document.execCommand("selectAll", false); document.execCommand("delete", false);
  let ok = document.execCommand("insertText", false, text);
  if (!ok || !(el.innerText || "").trim()) {
    const dt = new DataTransfer(); dt.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
  }
  await BF.sleep(150);
  return (el.innerText || el.value || "").trim().length > 0;
};
BF.pressEnter = (el) => { for (const t of ["keydown", "keypress", "keyup"]) el.dispatchEvent(new KeyboardEvent(t, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true })); };
// Generic adapter skeleton; providers override selectors only.
BF.makeAdapter = (cfg) => ({
  id: cfg.id, name: cfg.name, status: cfg.status, hosts: cfg.hosts,
  matches: () => cfg.hosts.some((h) => location.hostname === h || location.hostname.endsWith("." + h)),
  composer: () => BF.qa(cfg.composer).find(BF.visible) || null,
  sendButton: () => BF.qa(cfg.send).find((b) => BF.visible(b) && !b.disabled) || null,
  generating: () => BF.qa(cfg.stop).some(BF.visible),
  // Text of assistant messages only (never the composer, never user messages).
  assistantText: () => { const els = BF.qa(cfg.assistant); return els.map((e) => e.innerText || "").join("\n"); },
  async send(text) {
    const c = this.composer(); if (!c) throw new Error("Could not find the chat box. The site may have changed - see Troubleshooting.");
    if (!(await BF.setText(c, text))) throw new Error("Could not type into the chat box.");
    for (let i = 0; i < 20; i++) { const b = this.sendButton(); if (b) { b.click(); return; } await BF.sleep(150); }
    BF.pressEnter(c);
  },
});
