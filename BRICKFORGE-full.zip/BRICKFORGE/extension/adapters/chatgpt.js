BF.register(BF.makeAdapter({
  id: "chatgpt", name: "ChatGPT", status: "Experimental", hosts: ["chatgpt.com"],
  composer: ['#prompt-textarea', 'div[contenteditable="true"][data-virtualkeyboard]', 'textarea[placeholder]'],
  send: ['button[data-testid="send-button"]', 'button[aria-label*="Send" i]'],
  stop: ['button[data-testid="stop-button"]', 'button[aria-label*="Stop" i]'],
  assistant: ['[data-message-author-role="assistant"]'],
}));
