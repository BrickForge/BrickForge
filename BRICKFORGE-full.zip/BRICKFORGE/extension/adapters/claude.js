BF.register(BF.makeAdapter({
  id: "claude", name: "Claude", status: "Experimental", hosts: ["claude.ai"],
  composer: ['div[contenteditable="true"].ProseMirror', 'div[contenteditable="true"][role="textbox"]', 'fieldset div[contenteditable="true"]', 'div[contenteditable="true"]'],
  send: ['button[aria-label*="Send" i]', 'button[data-testid="send-button"]'],
  stop: ['button[aria-label*="Stop" i]', 'button[data-testid="stop-button"]'],
  assistant: ['[data-testid="assistant-message"]', '.font-claude-response', '.font-claude-message', '[data-is-streaming]'],
}));
