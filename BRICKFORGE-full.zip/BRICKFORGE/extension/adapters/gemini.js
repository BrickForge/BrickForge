BF.register(BF.makeAdapter({
  id: "gemini", name: "Gemini", status: "Experimental", hosts: ["gemini.google.com"],
  composer: ['rich-textarea div.ql-editor[contenteditable="true"]', 'div.ql-editor[contenteditable="true"]', 'div[contenteditable="true"][role="textbox"]'],
  send: ['button.send-button', 'button[aria-label*="Send" i]'],
  stop: ['button[aria-label*="Stop" i]', 'button.stop'],
  assistant: ['model-response', 'message-content', '.model-response-text'],
}));
