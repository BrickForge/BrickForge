// BRICKFORGE service worker: owns the single WebSocket to the local bridge.
// Content scripts never open sockets themselves (a web page origin is rejected by the bridge).
const URL = "ws://127.0.0.1:17640";
let ws = null, connectedAt = 0, status = { connected: false, bridge: null }, nextId = 1, pending = new Map(), retry = 0, timer = null;

function setStatus(s) { status = s; chrome.storage.session.set({ bf_status: s }).catch(() => {}); }
function failAll(kind, msg) { for (const [, p] of pending) p({ ok: false, kind, error: msg }); pending.clear(); }

function connect() {
  if (ws && (ws.readyState === 0 || ws.readyState === 1)) return;
  try { ws = new WebSocket(URL); } catch { schedule(); return; }
  ws.onopen = () => { retry = 0; clearTimeout(timer); timer = null; send({ type: "hello", id: "hello", role: "extension" }); };
  ws.onmessage = (e) => {
    let m; try { m = JSON.parse(e.data); } catch { return; }
    if (m.type === "status") setStatus({ connected: true, bridge: m });
    if (m.type === "cloud_result" || m.type === "tool_result" || m.type === "tools" || m.type === "mcp_status" || m.type === "status" || m.type === "error") {
      const p = pending.get(m.id); if (p) { pending.delete(m.id); p(m); }
    }
  };
  const sock = ws, down = () => {
    if (ws !== sock) return;   // a stale socket's late event must not clobber a newer one
    try { sock.close(); } catch {}
    setStatus({ connected: false, bridge: null });
    failAll("bridge_offline", "The BRICKFORGE bridge is not running. Double-click start.bat and keep its window open.");
    schedule();
  };
  // Chrome fires error THEN close; some runtimes fire only error. Handle either, once (schedule is idempotent).
  ws.onclose = down; ws.onerror = down;
}
function schedule() { if (timer) return; const d = Math.min(1000 * 2 ** retry, 10000); retry++; timer = setTimeout(() => { timer = null; connect(); }, d); }
function send(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }

function request(msg, timeoutMs) {
  return new Promise((resolve) => {
    if (!ws || ws.readyState !== 1) { connect(); return resolve({ ok: false, kind: "bridge_offline", error: "The BRICKFORGE bridge is not running. Double-click start.bat and keep its window open." }); }
    const id = "x" + nextId++;
    const t = setTimeout(() => { pending.delete(id); resolve({ ok: false, kind: "timeout", error: "No reply from the bridge." }); }, timeoutMs);
    pending.set(id, (r) => { clearTimeout(t); resolve(r); });
    send({ ...msg, id });
  });
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    if (m.type === "status") { const r = await request({ type: "status" }, 5000); reply(r.type === "status" ? { connected: true, bridge: r } : { connected: false, error: r.error }); }
    else if (m.type === "cloud") { reply(await request(m.msg, 130000)); }
    else if (m.type === "tools") { const r = await request({ type: "list_tools" }, 30000); reply(r); }
    else if (m.type === "call") {
      // Same call id from the page = same execution (bridge de-duplicates too).
      const r = await request({ type: "call_tool", name: m.name, arguments: m.args || {}, timeout: m.timeout || 120000 }, (m.timeout || 120000) + 10000);
      reply(r);
    } else if (m.type === "hello") { send({ type: "hello", id: "h" + nextId++, role: "extension", provider: m.provider }); reply({ ok: true }); }
  })();
  return true;
});
connect();
chrome.alarms?.create?.("keepalive", { periodInMinutes: 0.4 });
chrome.alarms?.onAlarm.addListener(() => { if (ws && ws.readyState === 1) send({ type: "ping", id: "k" }); else connect(); });
