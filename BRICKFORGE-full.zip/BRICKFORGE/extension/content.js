// BRICKFORGE content script: status bar + agent loop for the matched provider.
(() => {
  const A = Object.values(BF.adapters).find((a) => a.matches());
  if (!A || document.getElementById("bf-bar")) return;
  const P = BFP, rt = (m) => new Promise((res) => { try { chrome.runtime.sendMessage(m, (r) => res(r || { ok: false, kind: "no_reply", error: "No reply from extension." })); } catch (e) { res({ ok: false, kind: "extension_reloaded", error: "BRICKFORGE was updated. Reload this page." }); } });
  const S = { active: false, busy: false, seen: new Set(), lastText: "", lastChange: 0, incompleteNoted: "", ready: { color: "grey", msg: "Checking bridge..." } };

  // ---- bar UI ----
  const bar = document.createElement("div"); bar.id = "bf-bar";
  bar.innerHTML = `<img class="bf-logo" alt=""><span class="bf-dot grey"></span><span class="bf-msg">Checking bridge...</span><button>Start session</button>`;
  bar.querySelector("img").src = chrome.runtime.getURL("icons/icon32.png");
  document.documentElement.appendChild(bar);
  const dot = bar.querySelector(".bf-dot"), msg = bar.querySelector(".bf-msg"), btn = bar.querySelector("button");
  const show = (color, text, title) => { dot.className = "bf-dot " + color; msg.textContent = text; bar.title = title || text; };

  async function refresh() {
    const r = await rt({ type: "status" });
    if (!r.connected) { S.ready = { color: "grey", msg: "Bridge offline - run start.bat" }; }
    else {
      const b = r.bridge;
      if (b.place_loaded === true) S.ready = { color: "green", msg: S.active ? "Session active" : "Ready", detail: `${b.tools} tools` };
      else if (b.studio_app === true) S.ready = { color: "yellow", msg: "Studio open, no place loaded" };
      else S.ready = { color: "yellow", msg: "Open Studio + enable MCP server", detail: "Studio is not connected to the bridge (closed, or 'Enable Studio as MCP Server' is off)." };
    }
    show(S.ready.color, S.ready.msg, S.ready.detail || S.ready.msg);
    btn.disabled = S.ready.color === "grey";
  }
  setInterval(refresh, 4000); refresh();

  // ---- session ----
  async function start() {
    btn.disabled = true; show("yellow", "Starting...");
    const t = await rt({ type: "tools" });
    if (t.type !== "tools" || !t.tools || !t.tools.length) { await refresh(); show("yellow", "No Studio tools yet. Open a place in Studio and enable MCP."); btn.disabled = false; return; }
    S.seen.clear(); for (const c of P.parseCalls(A.assistantText()).calls) S.seen.add(key(c)); // old messages never re-run
    S.lastText = A.assistantText(); S.lastChange = Date.now();
    await rt({ type: "hello", provider: A.id });
    try { await A.send(P.instructions(t.tools)); } catch (e) { show("red", e.message); btn.disabled = false; return; }
    S.active = true; btn.textContent = "Stop"; btn.className = "stop"; btn.disabled = false; refresh();
  }
  function stop() { S.active = false; btn.textContent = "Start session"; btn.className = ""; refresh(); }
  btn.onclick = () => (S.active ? stop() : start());

  const key = (c) => c.id + "|" + c.tool + "|" + c.raw;
  async function waitReply() { // wait for generation to begin then finish
    for (let i = 0; i < 40 && !A.generating(); i++) await BF.sleep(250);
    while (A.generating()) await BF.sleep(500);
  }

  async function tick() {
    if (!S.active || S.busy) return;
    const now = Date.now(), text = A.assistantText();
    if (A.generating()) { S.lastChange = now; S.lastText = text; return; }
    if (text !== S.lastText) { S.lastText = text; S.lastChange = now; return; }
    if (now - S.lastChange < 2500) return; // let the DOM settle
    const { calls, errors, incomplete } = P.parseCalls(text);
    const fresh = calls.filter((c) => !S.seen.has(key(c)));
    if (!fresh.length && !errors.length && !incomplete) return;
    S.busy = true;
    try {
      const out = [];
      if (incomplete && !fresh.length && S.incompleteNoted !== text.slice(-200)) {
        S.incompleteNoted = text.slice(-200);
        out.push(`${P.RES} ${JSON.stringify({ ok: false, kind: "incomplete_command", error: `Your last command was cut off (no ${P.END} marker) and was NOT run. Re-send it as one complete line.` })} ${P.RES_END}`);
      }
      for (const e of errors) { if (S.seen.has("err|" + e)) continue; S.seen.add("err|" + e); out.push(`${P.RES} ${JSON.stringify({ ok: false, kind: "bad_command", error: e })} ${P.RES_END}`); }
      for (const c of fresh) {
        S.seen.add(key(c)); show("yellow", "Running " + c.tool + "...");
        out.push(P.formatResult(c.id, await rt({ type: "call", name: c.tool, args: c.args })));
      }
      if (out.length) { await A.send(out.join("\n")); await waitReply(); S.lastText = A.assistantText(); S.lastChange = Date.now(); }
    } catch (e) { show("red", e.message); }
    finally { S.busy = false; refresh(); }
  }
  setInterval(tick, 1000);
})();
