const $ = (i) => document.getElementById(i);
const bg = (msg) => new Promise((res) => chrome.runtime.sendMessage({ type: "cloud", msg }, (r) => res(r || { ok: false, error: "No reply from the extension." })));
const FMT = { Decal: ".png .jpg .bmp .tga (under 8000x8000)", Audio: ".mp3 .ogg .wav .flac (max 7 min)", Model: ".fbx .gltf .glb .rbxm .rbxmx", Animation: ".rbxm .rbxmx (exported from Studio)" };
const EXT = { png: "Decal", jpg: "Decal", jpeg: "Decal", bmp: "Decal", tga: "Decal", mp3: "Audio", ogg: "Audio", wav: "Audio", flac: "Audio", fbx: "Model", gltf: "Model", glb: "Model" };
const say = (id, t, c) => { $(id).textContent = t; $(id).className = "msg " + (c || ""); };
async function refresh() {
  const st = await new Promise((res) => chrome.runtime.sendMessage({ type: "status" }, res));
  const up = st && st.connected; $("bridge").textContent = up ? "Bridge connected" : "Bridge offline - run start.bat first"; $("bridge").className = "pill " + (up ? "ok" : "bad");
  if (!up) { $("lb").disabled = $("ub").disabled = true; return; }
  const s = await bg({ type: "cloud_status" }); $("store").textContent = s.storage || "";
  $("linked").hidden = !s.linked; $("conn").hidden = !!s.linked; $("ub").disabled = !s.linked; $("up").style.opacity = s.linked ? 1 : .5;
  if (s.linked) $("lt").textContent = s.mode === "oauth" ? `Connected as ${s.username || s.owner_id}` : `Linked with API key: ${s.owner_type} ${s.owner_id} (${s.key_hint})`;
  else if (s.client_id_set === false) { $("setup").open = true; say("cm", "One-time setup needed: add your Roblox app's Client ID below.", "err"); }
  $("lb").disabled = false; return s;
}
$("lf").onsubmit = async (e) => { e.preventDefault(); $("lb").disabled = true;
  const r = await bg({ type: "cloud_link", key: $("key").value, owner_type: $("ot").value, owner_id: $("oid").value });
  $("key").value = ""; if (r.ok) say("lm", "Saved. The key is checked by Roblox on your first upload.", "ok"); else say("lm", r.error, "err"); refresh(); };
let pollT = null;
$("conn").onclick = () => { chrome.tabs.create({ url: "http://127.0.0.1:17640/connect" }); say("cm", "Finish signing in on the Roblox tab...");
  clearInterval(pollT); let n = 0; pollT = setInterval(async () => { const s = await bg({ type: "cloud_status" }); if (s.linked || ++n > 90) { clearInterval(pollT); if (s.linked) say("cm", "Connected!", "ok"); refresh(); } }, 2000); };
$("cf").onsubmit = async (e) => { e.preventDefault(); const r = await bg({ type: "cloud_set_client_id", client_id: $("cid").value }); say("cm", r.ok ? "Saved. Now click Connect." : r.error, r.ok ? "ok" : "err"); if (r.ok) refresh(); };
$("unlink").onclick = async () => { await bg({ type: "cloud_unlink" }); say("lm", "Unlinked. The saved key was deleted from this PC.", "ok"); refresh(); };
$("at").onchange = () => ($("fmt").textContent = "Accepted: " + FMT[$("at").value]); $("at").onchange();
$("file").onchange = () => { const f = $("file").files[0]; if (!f) return; const e = f.name.split(".").pop().toLowerCase(); if (EXT[e]) $("at").value = EXT[e]; if (!$("nm").value) $("nm").value = f.name.replace(/\.[^.]+$/, "").slice(0, 50); $("at").onchange(); };
$("ub").onclick = async () => {
  const f = $("file").files[0]; if (!f) return say("um", "Choose a file first.", "err");
  if (f.size > 20 * 1024 * 1024) return say("um", "That file is over Roblox's 20 MB limit.", "err");
  $("ub").disabled = true; $("res").hidden = true; say("um", "Uploading and waiting for Roblox to process it...");
  const buf = new Uint8Array(await f.arrayBuffer()); let bin = ""; for (let i = 0; i < buf.length; i += 32768) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 32768));
  const r = await bg({ type: "cloud_upload", data: btoa(bin), filename: f.name, asset_type: $("at").value, display_name: $("nm").value, description: $("ds").value });
  $("ub").disabled = false;
  if (r.ok) { say("um", ""); $("res").hidden = false; $("rid").textContent = r.rbxassetid; $("rm").textContent = `${r.assetType} "${r.displayName || ""}" - moderation: ${r.moderation}`; }
  else say("um", r.error || "Upload failed.", "err");
};
$("cp").onclick = () => navigator.clipboard.writeText($("rid").textContent);
refresh();
