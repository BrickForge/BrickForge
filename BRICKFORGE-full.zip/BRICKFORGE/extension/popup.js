const $ = (id) => document.getElementById(id);
const row = (k, v, c) => `<div class="row"><span>${k}</span><b class="${c}">${v}</b></div>`;
async function load() {
  const r = await new Promise((res) => chrome.runtime.sendMessage({ type: "status" }, res));
  let h = "", help = "";
  if (!r || !r.connected) { h = row("Bridge", "Offline", "bad") + row("Studio", "-", "warn") + row("Tools", "-", "warn"); help = "Double-click start.bat in the BRICKFORGE folder and keep that window open."; }
  else { const b = r.bridge;
    h = row("Bridge", "Running v" + b.version, "ok") +
        row("Roblox Studio", b.studio_app === true ? "Connected" : b.studio_app === false ? "Not connected" : "Unknown", b.studio_app ? "ok" : "warn") +
        row("Place loaded", b.place_loaded === true ? "Yes" : b.place_loaded === false ? "No" : "Unknown", b.place_loaded ? "ok" : "warn") +
        row("Tools available", b.tools, b.tools ? "ok" : "warn") +
        row("AI providers", (b.providers || []).join(", ") || "none started", b.providers && b.providers.length ? "ok" : "warn");
    if (!b.studio_app) help = "Open Roblox Studio, load a place, then Assistant > ... > Manage MCP Servers > Enable Studio as MCP Server.";
    else if (!b.place_loaded) help = "Studio is connected but no place is open. Open or create a place.";
    else help = "All good. Open claude.ai, chatgpt.com or gemini.google.com and click Start session."; }
  $("rows").innerHTML = h; $("help").textContent = help;
}
$("r").onclick = load;
$("t").onclick = async () => { const t = await new Promise((res) => chrome.runtime.sendMessage({ type: "tools" }, res)); $("tools").hidden = false; $("tools").textContent = t && t.tools ? t.tools.map((x) => x.name).join("\n") || "(no tools yet)" : (t && t.error) || "Bridge offline"; };
load();

$("o").onclick = () => chrome.runtime.openOptionsPage();
