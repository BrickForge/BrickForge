// BRICKFORGE wire protocol between the AI's text and the bridge. Pure functions (unit-tested in tests/).
// Calls are single-line JSON between plain-text sentinels - NOT code fences - because chat sites
// truncate/abridge/re-render code blocks (a known ZeroScript failure). A call without its END
// marker is INCOMPLETE and is never executed.
(function (root) {
  const CALL = "@@BF_CALL", END = "@@BF_END", RES = "@@BF_RESULT", RES_END = "@@BF_RESULT_END";
  const MAX_RESULT = 24000;

  function parseJSON(s) {
    try { return JSON.parse(s); } catch {}
    try { return JSON.parse(s.replace(/[\u201C\u201D]/g, '"').replace(/[\u2018\u2019]/g, "'")); } catch {}
    return undefined;
  }

  // -> { calls:[{id,tool,args,raw}], errors:[string], incomplete:boolean }
  function parseCalls(text) {
    const calls = [], errors = []; let i = 0;
    for (;;) {
      const s = text.indexOf(CALL, i); if (s < 0) break;
      const e = text.indexOf(END, s + CALL.length);
      const nextCall = text.indexOf(CALL, s + CALL.length);
      if (e < 0 || (nextCall >= 0 && nextCall < e)) { return { calls, errors, incomplete: e < 0 }; }
      const body = text.slice(s + CALL.length, e).trim();
      const o = parseJSON(body);
      if (o === undefined || typeof o !== "object" || o === null) errors.push("Command is not valid JSON: " + body.slice(0, 120));
      else if (typeof o.tool !== "string" || !o.tool) errors.push("Command is missing a string 'tool' field.");
      else if (o.args !== undefined && (typeof o.args !== "object" || o.args === null || Array.isArray(o.args))) errors.push("'args' must be a JSON object.");
      else if (String(o.id) !== "EXAMPLE") calls.push({ id: String(o.id ?? ""), tool: o.tool, args: o.args || {}, raw: body });
      i = e + END.length;
    }
    return { calls, errors, incomplete: false };
  }

  function formatResult(id, r) {
    let text = r.ok ? (r.text || "") : "";
    const o = { id, ok: !!r.ok };
    if (r.ok) { if (text.length > MAX_RESULT) { text = text.slice(0, MAX_RESULT); o.truncated = true; } o.text = text; if (r.images && r.images.length) o.note = r.images.length + " image(s) omitted (text-only chat)"; if (r.isError) o.tool_reported_error = true; }
    else { o.kind = r.kind; o.error = r.error; }
    return `${RES} ${JSON.stringify(o)} ${RES_END}`;
  }

  function describeTools(tools) {
    const lines = tools.map((t) => {
      const props = (t.inputSchema && t.inputSchema.properties) || {}, req = new Set((t.inputSchema && t.inputSchema.required) || []);
      const args = Object.keys(props).map((k) => k + (req.has(k) ? "*" : "")).join(", ");
      return `- ${t.name}(${args}): ${(t.description || "").replace(/\s+/g, " ").slice(0, 160)}`;
    });
    let out = lines.join("\n"); if (out.length > 14000) out = out.slice(0, 14000) + "\n- ...(list truncated)";
    return out;
  }

  function instructions(tools) {
    return [
      "You are connected to Roblox Studio through BRICKFORGE. You can act in Studio by writing commands; an extension runs them and replies with the result.",
      "",
      "COMMAND FORMAT (exactly one line, plain text, NOT inside a code block):",
      `${CALL} {"id":"c1","tool":"TOOL_NAME","args":{"arg":"value"}} ${END}`,
      "",
      "RULES:",
      "1. 'id' must be unique for every command (c1, c2, c3...). Never reuse an id.",
      "2. Put commands at the END of your message, then stop and wait. Do not guess results.",
      `3. I will reply with ${RES} {...} ${RES_END}. Read it, then continue.`,
      "4. Never invent tool names. Use only the tools listed below. If a command fails, read the error and fix it.",
      "5. Before changing or deleting things, inspect first. Describe in one sentence what you are about to change.",
      "6. If a result says ok:false with kind bridge_offline, tell me; don't keep retrying.",
      "",
      "AVAILABLE TOOLS (* = required argument):",
      describeTools(tools),
      "",
      "Reply 'Ready' in one short sentence, then wait for my first request.",
    ].join("\n");
  }
  const api = { parseCalls, formatResult, describeTools, instructions, CALL, END, RES, RES_END };
  if (typeof module !== "undefined") module.exports = api; else root.BFP = api;
})(typeof window !== "undefined" ? window : globalThis);
