@echo off
setlocal
chcp 65001 >nul
title BRICKFORGE Bridge
cd /d "%~dp0bridge"
if not exist "brickforge_bridge\__main__.py" (
  echo ERROR: bridge files not found. If you opened this from inside a ZIP, extract the whole ZIP first.
  pause & exit /b 1
)
set "PY="
where py >nul 2>nul && py -3 -c "import sys;sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && python -c "import sys;sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python 3.9+ was not found. Install it from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH", then run start.bat again.
  pause & exit /b 1
)
echo.
echo   BRICKFORGE Bridge - keep this window open (minimize it).
echo   Nothing to install: this bridge has no extra dependencies.
echo.
echo   Your browser should open the BRICKFORGE page by itself.
echo   If not, open this address:  http://127.0.0.1:17640
echo.
%PY% -m brickforge_bridge
echo.
echo   Bridge stopped (exit code %errorlevel%). Scroll up for the error message.
echo   Log file: bridge\logs\bridge.log
echo   While this window is closed, 'refused to connect' is expected.
pause
