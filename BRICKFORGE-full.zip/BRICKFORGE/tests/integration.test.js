// Runs the REAL extension/background.js (stubbed chrome.*) against the REAL Python bridge + mock MCP server.
const { spawn } = require("child_process"), fs = require("fs"), os = require("os"), path = require("path");
const root = path.resolve(__dirname, ".."), bridgeDir = path.join(root, "bridge");
const cfg = path.join(os.tmpdir(), "bf_cfg_" + process.pid + ".json");
fs.writeFileSync(cfg, JSON.stringify({ mcpServers: { roblox: { command: path.join(bridgeDir, "tests", "mock_mcp.py"), args: [] } } }));
let n = 0, f = 0; const t = (name, c, x) => { n++; if (!c) { f++; console.log("FAIL", name, x ?? ""); } else console.log("PASS", name); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let listener; const chrome = { runtime: { onMessage: { addListener: (fn) => (listener = fn) } }, storage: { session: { set: async () => {} } }, alarms: { create() {}, onAlarm: { addListener() {} } } };
const ask = (m) => new Promise((res) => listener(m, {}, res));
(async () => {
  let bridge = spawn(process.platform === "win32" ? "python" : "python3", ["-m", "brickforge_bridge"], { cwd: bridgeDir, env: { ...process.env, BRICKFORGE_CONFIG: cfg, BRICKFORGE_PORT: "17640", BRICKFORGE_NO_BROWSER: "1", BRICKFORGE_HOME: os.tmpdir() + "/bf_home_" + process.pid }, stdio: "ignore" });
  await sleep(1500);
  new Function("chrome", fs.readFileSync(path.join(root, "extension", "background.js"), "utf8"))(chrome);
  let st; for (let i = 0; i < 40; i++) { st = await ask({ type: "status" }); if (st.connected && st.bridge.tools) break; await sleep(500); }
  t("extension connects to bridge", st.connected === true, JSON.stringify(st));
  t("status shows studio app + place + tools", st.bridge.studio_app === true && st.bridge.place_loaded === true && st.bridge.tools >= 4, JSON.stringify(st.bridge));
  const tl = await ask({ type: "tools" }); t("tool list via extension", tl.type === "tools" && tl.tools.some((x) => x.name === "echo"));
  await ask({ type: "hello", provider: "claude" }); await sleep(300);
  st = await ask({ type: "status" }); t("provider registered", st.bridge.providers.includes("claude"), JSON.stringify(st.bridge.providers));
  const r = await ask({ type: "call", name: "echo", args: { v: "from-extension" } }); t("tool call round-trip", r.ok && r.text === "echo:from-extension", JSON.stringify(r));
  const e = await ask({ type: "call", name: "boom", args: {} }); t("tool error returned as structured error", e.ok === false && e.kind === "tool_error");
  const rs = await Promise.all([1, 2, 3, 4, 5].map((i) => ask({ type: "call", name: "echo", args: { v: i } }))); t("5 parallel calls keep their own results", rs.every((x, i) => x.text === "echo:" + (i + 1)), JSON.stringify(rs.map((x) => x.text)));
  const KEY = "rbx-" + "K3y9Z8x7".repeat(6);
  const c0 = await ask({ type: "cloud", msg: { type: "cloud_status" } }); t("options page: cloud_status via extension (unlinked)", c0.type === "cloud_result" && c0.linked === false, JSON.stringify(c0));
  const c1 = await ask({ type: "cloud", msg: { type: "cloud_link", key: KEY, owner_type: "user", owner_id: "42" } }); t("options page: link via extension, key not echoed back", c1.ok && c1.linked && !JSON.stringify(c1).includes(KEY), JSON.stringify(c1));
  const c3 = await ask({ type: "cloud", msg: { type: "cloud_set_client_id", client_id: "abc" } }); t("options page: bad Client ID rejected with a clear message", c3.ok === false && c3.kind === "bad_input");
  const c2 = await ask({ type: "cloud", msg: { type: "cloud_unlink" } }); t("options page: unlink via extension", c2.linked === false);
  bridge.kill("SIGKILL"); await sleep(1200);
  const off = await ask({ type: "call", name: "echo", args: { v: 1 } }); t("bridge down -> clear bridge_offline error (no hang)", off.ok === false && off.kind === "bridge_offline" && /start\.bat/.test(off.error), JSON.stringify(off));
  const so = await ask({ type: "status" }); t("status reports disconnected", so.connected === false);
  bridge = spawn(process.platform === "win32" ? "python" : "python3", ["-m", "brickforge_bridge"], { cwd: bridgeDir, env: { ...process.env, BRICKFORGE_CONFIG: cfg, BRICKFORGE_PORT: "17640", BRICKFORGE_NO_BROWSER: "1", BRICKFORGE_HOME: os.tmpdir() + "/bf_home_" + process.pid }, stdio: "ignore" });
  let back; for (let i = 0; i < 40; i++) { await sleep(1000); back = await ask({ type: "status" }); if (back.connected) break; }
  t("extension auto-reconnects when bridge returns", back.connected === true);
  bridge.kill("SIGKILL"); console.log(`\n${n - f}/${n} passed`); process.exit(f ? 1 : 0);
})();
